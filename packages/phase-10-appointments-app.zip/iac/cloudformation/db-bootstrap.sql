-- Run as the RDS MySQL master/admin user after the CloudFormation stack is created.
-- Replace placeholders before running.

CREATE DATABASE IF NOT EXISTS `DB_NAME`;

CREATE USER IF NOT EXISTS 'DB_IAM_USER'@'%' IDENTIFIED WITH AWSAuthenticationPlugin AS 'RDS';

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
ON `DB_NAME`.*
TO 'DB_IAM_USER'@'%';

FLUSH PRIVILEGES;
