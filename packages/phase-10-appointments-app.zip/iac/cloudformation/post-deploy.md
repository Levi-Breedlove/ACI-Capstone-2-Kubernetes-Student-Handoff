# Post-Deploy Steps

## 1. Create Or Connect Source Repository

If `SourceProvider=CodeCommit`, create/push the repository named by `CodeCommitRepositoryName`.

If `SourceProvider=GitHub`, create a CodeStar connection first and pass `CodeStarConnectionArn` plus `GitHubFullRepositoryId`, for example `my-org/appointments-app`.

The repository root must be the contents of `appointments-app/`, not the whole migration package root.

## 2. Generate Kubeconfig

```bash
aws eks update-kubeconfig --name <EksClusterName> --region <AWS_REGION>
```

## 3. Install AWS Load Balancer Controller

The CloudFormation stack creates the IAM role for the controller. Install the controller into Kubernetes with Helm using that role through EKS Pod Identity or adapt the role to IRSA.

Example:

```bash
helm repo add eks https://aws.github.io/eks-charts
helm repo update
helm upgrade --install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system \
  --set clusterName=<EksClusterName> \
  --set serviceAccount.create=true \
  --set serviceAccount.name=aws-load-balancer-controller
```

Then associate the controller service account with the `LoadBalancerControllerRoleArn` output if you did not let the stack create the Pod Identity association.

## 4. Create Django Secret

```bash
kubectl create secret generic appointments-django \
  --from-literal=secret-key='<generate-a-long-random-value>'
```

## 5. Enable ALB Pod Readiness Gates

The app manifests already include pod spreading, a web PodDisruptionBudget, graceful termination timing, and faster ALB health checks. The hostname spread rule requires two node domains and spreads each new ReplicaSet by `pod-template-hash`, so the ALB target group should keep one healthy pod target on each worker node after rollout. For the strongest ALB-aware rollout behavior, label the `default` namespace before app pods are recreated:

```bash
kubectl label namespace default elbv2.k8s.aws/pod-readiness-gate-inject=enabled --overwrite
```

This is a one-time admin step because namespace mutation is cluster-scoped. The DeployPods CodeBuild role remains scoped to the `default` namespace.

## 6. Bootstrap RDS User And Schema

Use `db-bootstrap.sql`, replacing `DB_NAME` and `DB_IAM_USER` with the stack parameter values. Run it as the RDS master user.

The RDS instance is private, so a local laptop or Codespace usually cannot connect to it directly. The portable path is to run the packaged bootstrap job from inside EKS.

Prepare the rendered SQL file outside source control:

```bash
cp iac/cloudformation/db-bootstrap.sql /tmp/appointments-db-bootstrap.sql
sed -i "s/DB_NAME/<database-name>/g" /tmp/appointments-db-bootstrap.sql
sed -i "s/DB_IAM_USER/<database-iam-user>/g" /tmp/appointments-db-bootstrap.sql
```

Create temporary Kubernetes inputs. Do not commit or print the master password:

```bash
read -r -p "RDS master username: " DB_MASTER_USER
read -r -s -p "RDS master password: " DB_MASTER_PASSWORD
echo

kubectl create secret generic appointments-db-admin \
  --from-literal=username="$DB_MASTER_USER" \
  --from-literal=password="$DB_MASTER_PASSWORD"

unset DB_MASTER_PASSWORD

kubectl create configmap appointments-db-bootstrap-sql \
  --from-file=db-bootstrap.sql=/tmp/appointments-db-bootstrap.sql
```

Render and apply the bootstrap job:

```bash
cp iac/cloudformation/db-bootstrap-job.yml /tmp/appointments-db-bootstrap-job.yml
sed -i "s|RDS_ENDPOINT|<rds-endpoint>|g" /tmp/appointments-db-bootstrap-job.yml

kubectl delete job appointments-db-bootstrap --ignore-not-found
kubectl apply -f /tmp/appointments-db-bootstrap-job.yml
kubectl wait --for=condition=complete --timeout=300s job/appointments-db-bootstrap
kubectl logs job/appointments-db-bootstrap
```

Clean up temporary privileged material after success:

```bash
kubectl delete job appointments-db-bootstrap --ignore-not-found
kubectl delete secret appointments-db-admin --ignore-not-found
kubectl delete configmap appointments-db-bootstrap-sql --ignore-not-found
rm -f /tmp/appointments-db-bootstrap.sql /tmp/appointments-db-bootstrap-job.yml
```

## 7. Render Kubernetes Manifest Values

The `DeployPods` buildspec renders placeholders automatically during pipeline deployment. If applying manifests manually, replace placeholders in `appointments-app/manifests/appointments-deployment.yml`, `appointments-app/manifests/appointments-migrate-job.yml`, and `appointments-app/manifests/appointments-ingress.yml` with stack outputs and tag values:

- `ACCOUNT_ID`
- `AWS_REGION`
- `ECR_REPOSITORY`
- `RDS_ENDPOINT`
- `DB_IAM_USER`
- `DB_NAME`
- `DYNAMODB_ANNOUNCEMENTS_TABLE`
- `ALLOWED_HOSTS`
- `CSRF_TRUSTED_ORIGINS`
- `TAG_PROJECT`
- `TAG_PHASE`
- `TAG_ENVIRONMENT`
- `TAG_OWNER`
- `TAG_REPO`
- `TAG_MANAGED_BY`
- `ALB_CERTIFICATE_ARN`
- `ALB_INBOUND_CIDRS`
- `ALB_SECURITY_GROUP_PREFIX_LISTS`
- `CLOUDFRONT_ORIGIN_HEADER_NAME`
- `CLOUDFRONT_ORIGIN_HEADER_VALUE`
- `ALB_SSL_POLICY`
- `ALB_HTTPS_REDIRECT`
- `DJANGO_SECURE_HSTS_SECONDS`

If `ALB_CERTIFICATE_ARN` is blank, `DeployPods` leaves the Ingress HTTP-only. If it is set, `DeployPods` renders the certificate ARN, TLS policy, HTTPS listener, and optional HTTP-to-HTTPS redirect annotations. Use a certificate in the same AWS Region as the ALB and update `DjangoAllowedHosts` plus `DjangoCsrfTrustedOrigins` to the concrete demo hostname and `https://` origin.

For a no-custom-domain HTTPS demo, use CloudFront after the ALB DNS exists instead of setting `ALB_CERTIFICATE_ARN`. Deploy `iac/cloudformation/cloudfront-default-https.yaml` as a small companion stack with `OriginDnsName=<ALB_DNS>`, `OriginAccessHeaderName`, `OriginAccessHeaderValue`, and `PriceClass=PriceClass_100`. Generate the origin header value outside the repo, store the same value in SSM Parameter Store as a `SecureString`, and keep the CloudFront parameter file local and untracked. Also update the main app stack parameters `DjangoCsrfTrustedOrigins=https://*.amazonaws.com,https://*.cloudfront.net`, `CloudFrontOriginHeaderName`, `CloudFrontOriginHeaderValue=<ssm-securestring-name>`, and `AlbSecurityGroupPrefixLists=<cloudfront-origin-facing-prefix-list-id>`. This creates a default `https://*.cloudfront.net` front door and keeps origin traffic from CloudFront to the existing ALB on HTTP. Re-run `DeployPods` after the main stack parameter update so the web pods receive the CloudFront CSRF origin, secure cookie settings, ALB header gate, and CloudFront prefix-list restriction.

The CloudFront origin header value is a demo origin-bypass guard. `NoEcho` masks it in CloudFormation parameter views, but it is not full secret storage. `DeployPods` should receive the value through CodeBuild's Parameter Store environment-variable type, not as a plain CodeBuild project environment variable. The rendered Kubernetes Ingress annotation still contains the header condition value, so avoid diagnostic commands that print full Ingress annotations.

## 8. Run Pipeline

Push source to the configured branch. The pipeline runs unit tests, builds/pushes the ECR image, and then deploys according to `PipelineDeployMode`.

Keep `PipelineDeployMode=ManualApproval` until kubeconfig, AWS Load Balancer Controller, the Django secret, and the RDS bootstrap are complete. After the first path is proven, update the stack with `PipelineDeployMode=AutoDeploy` so `DeployPods` runs immediately after `BuildImage`.

The deploy stage applies the service account, runs the `appointments-migrate` Kubernetes Job, waits for it to complete, applies the service, ingress, web PodDisruptionBudget, and web deployment, and waits for the deployment rollout.

## 9. Verify

```bash
kubectl get pods
kubectl get job appointments-migrate
kubectl get service appointments-service
kubectl get ingress appointments-ingress
kubectl get pdb appointments-pdb
```

Open the ALB DNS name after the ingress is provisioned. Check `/healthz` first, then verify the appointment workflow.

For HTTPS demos, validate both paths:

```bash
curl -I http://<demo-hostname>/healthz
curl -I https://<demo-hostname>/healthz
```

The HTTP response should redirect to HTTPS when `AlbHttpsRedirect=true`, and the HTTPS response should return a valid certificate for the demo hostname.

For the no-custom-domain CloudFront path, validate the CloudFront output URL instead:

```bash
curl -I http://<cloudfront-domain>/healthz
curl -I https://<cloudfront-domain>/healthz
curl -I --max-time 8 http://<alb-dns>/healthz
```

The HTTP CloudFront response should redirect to HTTPS, and the HTTPS response should use the CloudFront default certificate. Direct ALB access from a normal client should fail at the security group layer or return `403` if it reaches the listener without the CloudFront origin header. A `404` fallback is acceptable only if the app is not reached. Direct ALB `200` is a failed hardening check.
