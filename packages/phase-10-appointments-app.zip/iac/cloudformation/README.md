# CloudFormation IaC

This directory contains AWS-native CloudFormation for the production migration package.

Files:

- `appointments-production.yaml`: production AWS foundation for the appointments app.
- `parameters.example.json`: example parameter file with placeholders.
- `cloudfront-default-https.yaml`: optional no-custom-domain HTTPS front door that points at the Kubernetes-managed ALB after it exists.
- `cloudfront-default-https.parameters.example.json`: example parameter file for the optional CloudFront stack.
- `db-bootstrap.sql`: SQL bootstrap for the MySQL IAM database user and schema.
- `db-bootstrap-job.yml`: Kubernetes Job template for running the SQL bootstrap from inside the EKS/VPC network.
- `post-deploy.md`: required post-stack Kubernetes and pipeline setup steps.

The template creates VPC networking, ECR, DynamoDB, RDS MySQL with IAM DB authentication enabled, EKS with managed nodes, IAM roles, EKS access entries, CodeBuild projects, CodePipeline, and supporting S3/CloudWatch permissions. Supported resources are tagged with the project tag parameters from `parameters.example.json`.

`PipelineDeployMode` controls the deploy stage flow. Keep `ManualApproval` for first launch so the pipeline pauses before `DeployPods` until the AWS Load Balancer Controller, Django Kubernetes Secret, and RDS bootstrap are complete. Use `AutoDeploy` after those prerequisites are proven so `DeployPods` runs immediately after a successful image build.

HTTPS is controlled by optional parameters. `AlbCertificateArn` defaults to blank for HTTP-only first launch. When set to a public ACM certificate ARN in the same Region, the DeployPods project renders the ALB HTTPS listener annotations, `AlbSslPolicy`, HTTP-to-HTTPS redirect, and secure Django cookie environment values.

For a no-custom-domain HTTPS demo, leave `AlbCertificateArn` blank on the main app stack and deploy `cloudfront-default-https.yaml` after the Kubernetes Ingress has an ALB DNS name. Set `OriginDnsName` to the ALB DNS name, keep `PriceClass=PriceClass_100`, and pass a generated `OriginAccessHeaderValue` through a local untracked parameter file. Store the same generated value in SSM Parameter Store as a `SecureString`, then update the main app stack parameters `DjangoCsrfTrustedOrigins`, `CloudFrontOriginHeaderName`, `CloudFrontOriginHeaderValue=<ssm-securestring-name>`, and `AlbSecurityGroupPrefixLists` before rerunning `DeployPods`. The companion stack creates one CloudFront distribution using the default `*.cloudfront.net` certificate and HTTP origin traffic to the existing ALB. The main stack update makes direct ALB access fail at the security group layer or at the listener default action instead of reaching the app. No Route 53 hosted zone, DNS record, or ACM certificate is required for that path.

`AlbInboundCidrs` controls which CIDRs can reach the public ALB listener ports when CloudFront prefix-list hardening is not enabled. `AlbSecurityGroupPrefixLists` should be set to the regional `com.amazonaws.global.cloudfront.origin-facing` prefix list ID for the CloudFront-only path. The CloudFront prefix list has a high security-group rule weight, so check the VPC quota `Inbound or outbound rules per security group` before applying it. `DjangoSecureHstsSeconds` defaults to `0` so temporary demo domains are not pinned by browsers.

CloudFormation does not store local kubeconfig credentials in this package. Generate kubeconfig after stack creation:

```bash
aws eks update-kubeconfig --name <cluster-name> --region <region>
```

Protect CloudFormation stack events, parameters, and state. The RDS master password parameter and CloudFront companion origin-header parameter are `NoEcho`, but operators should still treat deployment systems and logs as sensitive. Do not pass the origin header value to CodeBuild as a plaintext environment variable; use `CloudFrontOriginHeaderValue` to pass the SSM `SecureString` parameter name.

Create the stack with:

```bash
aws cloudformation create-stack \
  --stack-name appointments-prod \
  --template-body file://iac/cloudformation/appointments-production.yaml \
  --parameters file://iac/cloudformation/parameters.example.json \
  --capabilities CAPABILITY_IAM \
  --tags \
    Key=Project,Value=appointments \
    Key=Phase,Value=10 \
    Key=Environment,Value=prod \
    Key=Owner,Value=Student \
    Key=Repo,Value=student-appointments-scheduler \
    Key=ManagedBy,Value=phase10-runbook
```

For another student account, update `OwnerTagValue` and `RepoTagValue` in the local parameter file and adjust the stack `--tags` values before deployment. Do not put secrets, account IDs, passwords, tokens, or private endpoints in tags.
