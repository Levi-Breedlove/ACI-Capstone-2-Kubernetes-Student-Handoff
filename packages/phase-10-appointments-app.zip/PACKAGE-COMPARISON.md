# Package Comparison

This package is the production-style migration artifact for the Phase 10 Appointments Scheduler. It is meant to be compared with the lab zip so the reader can see the path from lab deployment to own-account AWS deployment.

## Summary

| Area | Lab Baseline | Production Package |
| --- | --- | --- |
| Account model | Lab-specific assumptions | Parameterized own-account deployment. |
| Infrastructure | Lab-provided resources and references | CloudFormation-managed VPC, EKS, RDS, DynamoDB, ECR, CodePipeline, CodeBuild, IAM, and artifact storage. |
| Public routing | ALB/Kubernetes lab path | ALB first, then optional CloudFront default-domain HTTPS and CloudFront-only origin hardening. |
| Kubernetes exposure | Lab manifests | `ClusterIP` Service behind AWS Load Balancer Controller-managed ALB Ingress with pod-IP targets. |
| Runtime hardening | Original container path | Non-root UID/GID `10001`, dropped Linux capabilities, no privilege escalation, RuntimeDefault seccomp, and reduced runtime package surface. |
| Secrets | Lab-oriented configuration | RDS password and CloudFront origin header supplied outside source control; DeployPods reads the header through CodeBuild `PARAMETER_STORE`. |
| Cleanup | Lab cleanup expectations | Dry-run-first teardown helper with Kubernetes, ALB, CloudFront, SSM, ECR, S3, stack, snapshot, log, and source-repo awareness. |

## Production Security Changes

The production package removes or parameterizes account-specific values and keeps secrets outside tracked files. The important security changes are:

- `DJANGO_SECRET_KEY` is required from a Kubernetes Secret.
- `DjangoAllowedHosts` and `DjangoCsrfTrustedOrigins` are stack parameters rendered into manifests.
- The CloudFront origin-header value is generated outside the repo, stored in SSM Parameter Store as a `SecureString`, and passed to DeployPods as CodeBuild `PARAMETER_STORE`.
- The ALB can be restricted to AWS-managed CloudFront origin-facing prefix-list traffic.
- The ALB listener can forward only requests containing the expected CloudFront origin header.
- The listener default action denies unmatched requests instead of forwarding them to the app.
- The app container runs as non-root UID/GID `10001`.
- The Kubernetes deployment disables privilege escalation, drops Linux capabilities, and uses `RuntimeDefault` seccomp.
- The runtime uses PyMySQL and the RDS CA bundle instead of the earlier MariaDB C client runtime path.

The final no-custom-domain demo path is:

```text
Browser HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> Kubernetes Ingress -> ClusterIP Service -> pods
```

That is not end-to-end TLS. It is a low-cost, demo-safe edge pattern.

## Resource And IAM Changes

The production package adds the AWS-side infrastructure needed to relaunch the environment:

- VPC, public/private subnets, internet gateway, route tables, NAT gateway, and security groups.
- EKS cluster, managed node group, add-ons, and Pod Identity associations.
- Private RDS MySQL with IAM database authentication.
- DynamoDB announcements table.
- ECR repository with image scan support.
- CodePipeline with separate UnitTest, BuildImage, and DeployPods CodeBuild projects.
- Stage-specific IAM roles instead of one broad deployment role.
- Namespace-scoped Kubernetes deployment access for DeployPods.
- AWS Load Balancer Controller permissions through its own role.

The design lets operators explain which actor needs each permission: pipeline orchestration, test execution, image publishing, Kubernetes deployment, app runtime AWS access, ALB management, and database access.

## Reliability Changes

The Kubernetes and ALB path was hardened for a clear two-pod availability demo:

- Two web replicas.
- Pod-IP ALB target group.
- Topology spread across worker nodes.
- `maxUnavailable: 0` rolling update.
- PodDisruptionBudget with at least one pod available.
- `/healthz` readiness/liveness checks.
- ALB readiness-gate guidance.
- Graceful drain and shorter target deregistration delay.

One target group is intentional for the first demo. It shows a single pool of healthy pod targets. Active/passive target groups are a future design because they require a separate traffic-switching mechanism.

## Dependency And Vulnerability Changes

The production package was refreshed during the security-hardening pass:

- Django remains on the current 5.2 LTS line for the Python runtime.
- `django-iam-dbauth`, `PyMySQL`, `boto3`, and `gunicorn` were updated to current compatible runtime versions.
- Dev/test dependencies were updated to current compatible versions.
- The patched set passed Django tests and `pip check` in a temporary validation environment.
- Earlier MariaDB/MySQL, Perl, and PAM runtime package exposure was removed from the final runtime image path.

## What To Verify After Deployment

- CloudFront HTTPS `/healthz` returns 200.
- CloudFront HTTPS `/` returns 200.
- Direct ALB `/healthz` from a normal laptop times out, returns `403`, or returns fallback `404`; it does not return the app.
- ALB target health shows healthy pod-IP targets.
- Deployment is `2/2`.
- Runtime UID/GID is `10001`.
- CodeBuild shows `CLOUDFRONT_ORIGIN_HEADER_VALUE` as `PARAMETER_STORE`.
- ECR scan results are reviewed for the built image.
- Teardown removes the CloudFront companion stack and SSM origin-header parameter in addition to the main stack resources.
