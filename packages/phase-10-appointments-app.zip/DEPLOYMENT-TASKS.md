# Student Deployment Tasks

This task tracker pairs with `DEPLOYMENT-RUNBOOK.md`. Use it to track a fresh deployment of the Phase 10 production package into a student-owned AWS account or an approved AWS sandbox.

Status values:

```text
Not Started
In Progress
Needs Approval
Blocked
Complete
Skipped With Reason
```

Do not mark a task complete unless the command output or AWS console state proves it. Do not write account IDs, ARNs, endpoints, kubeconfig contents, passwords, generated secret values, or raw CloudFront origin-header values into this file.

## Target Architecture

The deployment target is:

```text
CodeCommit or GitHub source
-> CodePipeline
-> CodeBuild UnitTest
-> CodeBuild BuildImage
-> ECR
-> Manual ApproveDeploy gate for first launch
-> CodeBuild DeployPods
-> EKS private worker nodes
-> Kubernetes ClusterIP Service
-> AWS Load Balancer Controller-managed ALB
-> optional CloudFront default-domain HTTPS companion stack
-> private RDS MySQL
-> DynamoDB announcements table
```

The final affordable HTTPS demo path is:

```text
Browser -> HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> pods
```

This is not end-to-end TLS.

## Deployment Completion Boundary

Required for the demo:

- [ ] Production package integrity passes.
- [ ] AWS identity, Region, and budget gate are confirmed.
- [ ] Application source repository contains the contents of `appointments-app/` as its root.
- [ ] Main CloudFormation template validates before stack creation.
- [ ] Main stack reaches a stable complete state.
- [ ] EKS cluster and worker nodes are healthy.
- [ ] AWS Load Balancer Controller is installed and healthy.
- [ ] `appointments-django` Kubernetes Secret exists without exposing the secret value.
- [ ] Private RDS bootstrap completes from inside EKS.
- [ ] First pipeline deploy is manually approved only after prerequisites are complete.
- [ ] Migration Job completes.
- [ ] Web Deployment is `2/2`.
- [ ] Kubernetes Service is `ClusterIP`.
- [ ] ALB target group registers healthy pod IP targets.
- [ ] ALB `/healthz` returns `200` before CloudFront hardening.
- [ ] Container runs as UID/GID `10001`.
- [ ] Kubernetes runtime security context is verified.
- [ ] CloudFront HTTPS `/healthz` returns `200`.
- [ ] CloudFront HTTPS `/` returns `200`.
- [ ] Direct ALB access no longer returns the app after origin hardening.
- [ ] RDS is not publicly accessible.
- [ ] App writes work through the approved app path, if app-data testing is approved.
- [ ] Teardown plan is understood before the demo is left running.

## Package Validation

- [ ] Confirm deployable package is `phase-10-appointments-app.zip`.
- [ ] Confirm lab package is comparison-only: `phase-10-appointments-app-lab.zip`.
- [ ] Run `unzip -t phase-10-appointments-app.zip`.
- [ ] Run `unzip -t phase-10-appointments-app-lab.zip`.
- [ ] Record production zip entry count locally if needed.
- [ ] Record production zip byte size locally if needed.
- [ ] Record production zip SHA-256 locally if needed.
- [ ] Confirm `DEPLOYMENT-RUNBOOK.md` exists inside the production package.
- [ ] Confirm `DEPLOYMENT-TASKS.md` exists inside the production package.
- [ ] Confirm `NETWORK-SECURITY-REVIEW.md` exists inside the production package.
- [ ] Confirm no `.env`, kubeconfig, AWS credential, private key, raw origin-header value, or database password file is packaged.

## Local Tooling

- [ ] Confirm AWS CLI is installed.
- [ ] Confirm Git is installed.
- [ ] Confirm `unzip` is installed.
- [ ] Confirm `jq` is installed.
- [ ] Confirm `openssl` is installed.
- [ ] Confirm `kubectl` is installed.
- [ ] Confirm Helm is installed.
- [ ] Confirm `cfn-lint` is installed.
- [ ] Optional: confirm Docker is installed for local image inspection.
- [ ] Optional: confirm MySQL client is installed for SQL troubleshooting.
- [ ] If using Codex, confirm Agent Toolkit for AWS / `aws-core` is available or document the fallback.

## AWS Preflight

- [ ] Choose AWS profile.
- [ ] Choose AWS Region, normally `us-west-1`.
- [ ] Choose main stack name, normally `appointments-prod`.
- [ ] Confirm the AWS account is the intended student account or approved sandbox.
- [ ] Confirm the principal is not the AWS root user.
- [ ] Confirm an AWS Budget or billing alert exists.
- [ ] Review expected billable services: EKS, EC2 worker nodes, NAT Gateway, RDS, ALB, public IPv4, EBS, ECR, CloudWatch Logs, CloudFront, and retained snapshots.
- [ ] Run `aws sts get-caller-identity`.
- [ ] Run `aws configure list`.
- [ ] Run read-only collision checks for CloudFormation, EKS, ECR, RDS, DynamoDB, CodePipeline, CodeBuild, ALB, NAT Gateway, and EIP.
- [ ] Stop if unexpected resources already exist.

## Source Repository

- [ ] Choose source provider: CodeCommit or GitHub.
- [ ] Confirm `SourceProvider` parameter matches the source choice.
- [ ] Confirm source branch, normally `main`.
- [ ] Extract production package outside Git, preferably under `/tmp`.
- [ ] Confirm app source root is `appointments-app/`.
- [ ] Create or select source repository only after approval.
- [ ] Push only the contents of `appointments-app/` to the source repository root.
- [ ] Confirm source repository contains `Dockerfile`, `manage.py`, `buildspecs/`, `manifests/`, `appointments/`, and `hairdresser_django/`.
- [ ] Confirm package docs, local parameter files, kubeconfig files, and secrets were not pushed to the app source repo.

## CloudFormation Preparation

- [ ] Copy `iac/cloudformation/parameters.example.json` to `/tmp/appointments-prod-parameters.json`.
- [ ] Set `/tmp/appointments-prod-parameters.json` mode to `600`.
- [ ] Fill in non-secret deployment values.
- [ ] Fill in the RDS master password locally without printing it.
- [ ] Keep `PipelineDeployMode=ManualApproval` for first launch.
- [ ] Keep `CloudFrontOriginHeaderValue` blank for the first main stack launch.
- [ ] Keep `AlbSecurityGroupPrefixLists` blank for the first main stack launch.
- [ ] Keep `DjangoSecureHstsSeconds=0` for the CloudFront default-domain demo.
- [ ] Run `cfn-lint -i W1030 W1011 -- iac/cloudformation/appointments-production.yaml`.
- [ ] Run `cfn-lint iac/cloudformation/cloudfront-default-https.yaml`.
- [ ] Run AWS `cloudformation validate-template` for the main template.
- [ ] Run AWS `cloudformation validate-template` for the CloudFront companion template.
- [ ] Review IAM capability requirement: `CAPABILITY_IAM`.

## Main Stack Creation

- [ ] State AWS profile, account, Region, stack name, template path, parameter file path, and expected cost-bearing resources.
- [ ] Get explicit approval before stack creation.
- [ ] Create the main CloudFormation stack.
- [ ] Wait for stack completion.
- [ ] Capture non-secret output keys.
- [ ] Confirm stack status is stable.
- [ ] If creation fails, inspect events and identify root cause before retrying or deleting.

## EKS And Kubernetes Prerequisites

- [ ] Generate kubeconfig outside Git, preferably `/tmp/appointments-prod-kubeconfig`.
- [ ] Set kubeconfig mode to `600`.
- [ ] Confirm EKS cluster is `ACTIVE`.
- [ ] Confirm managed node group is healthy.
- [ ] Confirm nodes are `Ready`.
- [ ] Confirm core system pods are running.
- [ ] Install or verify AWS Load Balancer Controller only after approval.
- [ ] Confirm `alb` IngressClass exists.
- [ ] Create `appointments-django` Kubernetes Secret without printing the secret value.
- [ ] Enable ALB readiness-gate namespace label before app pods are created.
- [ ] Bootstrap private RDS from inside EKS only after approval.
- [ ] Remove temporary RDS bootstrap Secret, ConfigMap, Job, SQL files, and local privileged files after success.

## First Pipeline Deploy

- [ ] Confirm pipeline is paused at `ApproveDeploy`.
- [ ] Confirm EKS, controller, Secret, readiness label, and RDS bootstrap are complete.
- [ ] Approve only the intended current execution.
- [ ] Monitor `Source`.
- [ ] Monitor `UnitTest`.
- [ ] Monitor `BuildImage`.
- [ ] Monitor `DeployPods`.
- [ ] Confirm `DeployPods` succeeds.
- [ ] If a stage fails, inspect the specific CodeBuild or CodePipeline failure before rerunning.

## ALB And Kubernetes Validation

- [ ] Confirm migration Job completed.
- [ ] Confirm Deployment is `2/2`.
- [ ] Confirm pods are ready.
- [ ] Confirm pods are spread across worker nodes when possible.
- [ ] Confirm Service type is `ClusterIP`.
- [ ] Confirm Ingress class is `alb`.
- [ ] Confirm Ingress target type is `ip`.
- [ ] Confirm ALB DNS name exists.
- [ ] Confirm target group contains pod IP targets.
- [ ] Confirm target health is healthy.
- [ ] Confirm ALB `/healthz` returns `200`.
- [ ] Confirm ALB `/` returns `200`.
- [ ] Do not proceed to CloudFront until the ALB path works.

## Container Hardening Validation

- [ ] Confirm Dockerfile creates non-root UID/GID `10001`.
- [ ] Confirm Deployment sets `runAsNonRoot: true`.
- [ ] Confirm Deployment sets `runAsUser: 10001`.
- [ ] Confirm Deployment sets `runAsGroup: 10001`.
- [ ] Confirm Deployment sets `allowPrivilegeEscalation: false`.
- [ ] Confirm Deployment drops Linux capabilities.
- [ ] Confirm Deployment uses `RuntimeDefault` seccomp.
- [ ] Confirm live runtime `id` shows UID/GID `10001`.
- [ ] Confirm app uses Gunicorn, not Django `runserver`, in production runtime.
- [ ] Review ECR scan results for the image that was deployed.

## CloudFront HTTPS Checkpoint

- [ ] Get explicit approval before creating the CloudFront companion stack.
- [ ] Generate origin-header value outside Git.
- [ ] Keep raw origin-header value out of chat, docs, commands with `set -x`, and committed files.
- [ ] Create local CloudFront parameter file outside Git.
- [ ] Create or update `appointments-prod-cloudfront-https`.
- [ ] Confirm CloudFront distribution is deployed.
- [ ] Confirm CloudFront HTTP redirects to HTTPS.
- [ ] Confirm CloudFront HTTPS `/healthz` returns `200`.
- [ ] Confirm CloudFront HTTPS `/` returns `200`.
- [ ] Record CloudFront domain only in placeholder-safe notes if needed.
- [ ] Explain that direct ALB access may still return the app before origin hardening.

## ALB Origin Hardening

- [ ] Get explicit approval before creating or updating SSM parameters.
- [ ] Store origin-header value in SSM Parameter Store as a `SecureString`.
- [ ] Get the regional AWS-managed CloudFront origin-facing prefix list ID.
- [ ] Check security group rule quota impact before applying the prefix list.
- [ ] Update main stack parameter file so `CloudFrontOriginHeaderValue` is the SSM parameter name, not the raw value.
- [ ] Update `DjangoCsrfTrustedOrigins` to include `https://*.cloudfront.net`.
- [ ] Update `AlbSecurityGroupPrefixLists` to the CloudFront origin-facing prefix list ID.
- [ ] Update the main stack only after approval.
- [ ] Rerun or approve `DeployPods`.
- [ ] Confirm CodeBuild shows `CLOUDFRONT_ORIGIN_HEADER_VALUE` as `PARAMETER_STORE`, not `PLAINTEXT`.
- [ ] Confirm CloudFront HTTPS `/healthz` returns `200`.
- [ ] Confirm CloudFront HTTPS `/` returns `200`.
- [ ] Confirm direct ALB `/healthz` times out, returns `403`, or returns a safe fallback.
- [ ] Confirm direct ALB access does not return the application.

## Network Security Review

- [ ] Use `NETWORK-SECURITY-REVIEW.md`.
- [ ] Confirm browser-facing traffic is HTTPS to CloudFront.
- [ ] Confirm CloudFront-to-ALB traffic is HTTP for this demo.
- [ ] Confirm ALB-to-pod traffic is HTTP for this demo.
- [ ] Confirm the docs do not claim end-to-end TLS.
- [ ] Confirm pods are not directly public.
- [ ] Confirm worker nodes are private.
- [ ] Confirm RDS is not publicly accessible.
- [ ] Confirm RDS allows database access only from the intended app/EKS path.
- [ ] Confirm app writes still work if app-data testing is approved.
- [ ] Confirm health endpoint does not expose secrets, stack traces, environment variables, pod metadata, or database details.
- [ ] Confirm no secrets are printed in logs.

## Optional Application Workflow Validation

- [ ] Get approval before creating test data.
- [ ] Load the CloudFront HTTPS URL.
- [ ] Create a test appointment.
- [ ] Confirm the appointment persists after refresh.
- [ ] Confirm database-backed write path is working.
- [ ] Clear test data if desired.
- [ ] Do not store real personal data in the demo database.

## Teardown Readiness

- [ ] Review `CLEANUP.md`.
- [ ] Identify main stack name.
- [ ] Identify CloudFront companion stack name.
- [ ] Identify SSM origin-header parameter name.
- [ ] Identify source repository retention decision.
- [ ] Decide whether to retain or delete RDS snapshots.
- [ ] Delete Kubernetes-managed app resources before deleting the EKS stack.
- [ ] Wait for the Kubernetes-managed ALB to disappear before deleting the main stack.
- [ ] Delete CloudFront companion stack.
- [ ] Delete SSM origin-header parameter.
- [ ] Delete main stack.
- [ ] Confirm no active NAT Gateway, ALB, EKS cluster, RDS instance, ECR repository, DynamoDB table, or app-owned public IPv4 resource remains unless intentionally retained.

## Production Hardening Backlog

These items are useful future upgrades, but they are not required for the affordable student demo.

- [ ] Restrict EKS public API endpoint to known admin CIDRs after planning the DeployPods access path.
- [ ] Use private EKS endpoint access with a VPC-connected deployment runner when operationally ready.
- [ ] Replace wildcard `DjangoAllowedHosts` with explicit hostnames.
- [ ] Replace broad CSRF origins with exact final CloudFront or custom domain origins.
- [ ] Add CloudFront-to-ALB HTTPS with a custom domain and ACM certificate.
- [ ] Add AWS WAF on CloudFront with managed rules and rate-based rules.
- [ ] Enable cost-aware CloudFront and ALB access logging.
- [ ] Add CloudWatch alarms and dashboards.
- [ ] Move RDS password workflow to Secrets Manager or SSM SecureString dynamic references.
- [ ] Evaluate pod-level TLS, mTLS, cert-manager, or service mesh only for an advanced security lesson.
- [ ] Add least-privilege refinements after CloudTrail and deployment behavior are reviewed.

## Blockers To Stop For

Stop and ask for help if any of these happen:

- AWS identity is the wrong account.
- AWS root credentials are being used.
- A secret appears in chat, logs, or tracked files.
- CloudFormation validation fails.
- Stack creation fails and the root cause is not understood.
- AWS Load Balancer Controller is unhealthy.
- RDS bootstrap fails.
- Direct ALB access still returns the app after origin hardening.
- Pods or worker nodes are publicly reachable.
- RDS is publicly accessible.
- Cost-bearing resources remain after intended teardown.
