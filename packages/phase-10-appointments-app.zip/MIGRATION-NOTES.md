# Migration Notes

Changes from the lab package:

- Removed hardcoded Django secret key. Production now requires `DJANGO_SECRET_KEY`.
- `DEBUG` is controlled by `DJANGO_DEBUG` and defaults to off.
- `ALLOWED_HOSTS` and `CSRF_TRUSTED_ORIGINS` are environment-driven.
- DynamoDB announcements table is controlled by `ANNOUNCEMENTS_TABLE`.
- ECR repository and EKS cluster names in buildspecs are environment variables.
- Kubernetes deployment uses placeholders instead of lab account, region, ECR, RDS, and database values.
- `DeployPods` buildspec renders those placeholders from CodeBuild environment variables before applying manifests.
- `DeployPods` renders the source commit tag into the migration job and web deployment image references so Kubernetes rolls out the exact image from the current pipeline execution.
- Kubernetes manifest environment values are quoted so first-launch wildcard host values and CSRF URLs render as valid YAML.
- Added optional ALB HTTPS rendering through `AlbCertificateArn`, `AlbSslPolicy`, `AlbHttpsRedirect`, and `AlbInboundCidrs` without creating a second ALB or target group.
- Added optional no-custom-domain HTTPS through the companion `iac/cloudformation/cloudfront-default-https.yaml` template, which points a CloudFront default-domain distribution at the existing Kubernetes-managed ALB.
- Added CloudFront origin-bypass hardening for the no-custom-domain HTTPS path: CloudFront sends a custom origin header, the ALB listener rule forwards only when that header is present, the listener default action denies unmatched requests, and the ALB security group can be restricted to the AWS-managed CloudFront origin-facing prefix list.
- Added Django proxy/HTTPS hardening settings for ALB and CloudFront deployments: `SECURE_PROXY_SSL_HEADER`, secure cookies when public HTTPS is enabled, optional ALB SSL redirect, HSTS configured by parameter, `X_FRAME_OPTIONS=DENY`, content-type sniffing protection, and same-origin referrer policy.
- Added `appointments-serviceaccount.yml` for the `appointments-sa` service account used by EKS Pod Identity.
- Added `appointments-migrate-job.yml` so `DeployPods` can run Django migrations before rolling out web pods.
- Added configurable pipeline deployment mode. `ManualApproval` keeps the `ApproveDeploy` gate for first-launch safety; `AutoDeploy` removes the gate after post-stack setup is proven so the real pipeline deploys after image build.
- Added `iac/cloudformation/db-bootstrap-job.yml` so the RDS IAM user/schema bootstrap can run from inside EKS against the private RDS endpoint.
- Added Kubernetes Secret reference for `DJANGO_SECRET_KEY`.
- Switched the production container command from Django `runserver` to Gunicorn.
- Refreshed compatible Python dependencies during the security-hardening pass. Django remains on the current 5.2 LTS line for the Python runtime; `django-iam-dbauth`, `PyMySQL`, `boto3`, `gunicorn`, `coverage`, `pylint-django`, and `unittest-xml-reporting` were updated to current compatible package-index versions and verified with Django tests plus `pip check`.
- Changed the production Dockerfile to build Python wheels in a builder stage, use an Alpine runtime, run the app as non-root UID/GID `10001`, and keep compiler, MariaDB/MySQL, Perl, and PAM packages out of the final runtime image.
- Replaced `mysqlclient` with PyMySQL through the `MySQLdb` compatibility shim so the IAM-authenticated Django MySQL backend can run without the MariaDB C client runtime package.
- Added the Amazon RDS global CA bundle to the app image and configured the PyMySQL TLS context to verify the RDS server certificate instead of disabling certificate verification.
- Added a lightweight `/healthz` endpoint plus Kubernetes readiness/liveness probes.
- Added clean ALB rerouting settings: topology spread constraints, `minDomains: 2` hostname placement, per-ReplicaSet `pod-template-hash` spread matching, zero-unavailable rolling updates, a web PodDisruptionBudget, faster ALB/readiness checks, a shorter target group deregistration delay, and a `preStop` drain window.
- Added database-backed `AppointmentSlot` locks so overlapping appointment requests for the same hairdresser/time range are rejected by a transactional unique constraint, not only by disabled UI buttons.
- Changed the production service to `ClusterIP` and moved ALB behavior to the Ingress annotations.
- Added `scripts/cluster.starter.yaml` as a minimal eksctl starter.
- Added `scripts/config.example` as a sanitized kubeconfig shape.
- Added AWS-native CloudFormation IaC under `iac/cloudformation/` for VPC, ECR, DynamoDB, RDS, EKS, IAM, CodeBuild, CodePipeline, and artifact storage.

Lab assumptions removed or parameterized:

- AWS account ID.
- AWS region.
- ECR repository URI.
- RDS endpoint and database identity.
- DynamoDB table name.
- EKS cluster name for deployment.
- Django host and CSRF trust settings.

Production hardening note:

- `DjangoAllowedHosts=*` is acceptable only as a temporary first-launch ALB discovery value. Replace it and the broad CSRF origin with the actual ALB DNS name or custom domain after the initial ingress is created.
- For no-custom-domain HTTPS demos, use the CloudFront default HTTPS URL, keep `DjangoSecureHstsSeconds=0`, and validate that direct ALB access does not return the app.
- The intended demo path is `Browser -> HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> pods`. This is not end-to-end TLS.
- For the main app stack, `CloudFrontOriginHeaderValue` should be the SSM Parameter Store `SecureString` name that contains the generated header value. Do not set it to the raw header value, because CodeBuild project environment variables can be displayed as plaintext.
- For polished HTTPS demos, prefer a public ACM certificate and a real demo hostname. Keep `DjangoSecureHstsSeconds=0` until the hostname is stable, then raise it deliberately.
- The app container is intended to run as UID/GID `10001` with `runAsNonRoot`, `allowPrivilegeEscalation: false`, dropped Linux capabilities, and `RuntimeDefault` seccomp.
- The validated hardened image should have no ECR findings for the previous MariaDB/Perl/PAM CVE set. Re-scan ECR after every new base image or dependency update.

Not included:

- Local kubeconfig or auth files. Only a sanitized `scripts/config.example` is included.
- AWS credentials.
- Lab account-specific cluster ARNs, VPC IDs, subnet IDs, and security group IDs.
- Fully automated in-cluster Kubernetes bootstrapping. CloudFormation creates the AWS-side resources and IAM; `iac/cloudformation/post-deploy.md` covers the required Kubernetes API and Helm steps.
