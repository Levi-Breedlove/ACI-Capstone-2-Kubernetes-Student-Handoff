# Phase 10 Appointments Scheduler Production Package

This package is the deployable production-style version of the Phase 10 appointments scheduler for a student's own AWS account.

It includes the Django app, production Dockerfile, CodeBuild buildspecs, Kubernetes manifests, CloudFormation templates, CloudFront HTTPS support, ALB origin hardening support, and deployment/cleanup notes.

## Start Here

When this package is used from the student handoff repository, follow the outer `WALKTHROUGH.md` and `WALKTHROUGH-CHECKLIST.md` first. Inside this package, use:

1. `AI-ASSISTED-DEPLOYMENT-GUIDE.md` when working with Codex or another AI assistant.
2. `DEPLOYMENT.md` for the chronological package deployment notes.
3. `IAM-PERMISSIONS.md` for service permissions.
4. `MIGRATION-NOTES.md` for lab-to-production differences.
5. `iac/cloudformation/README.md` for stack details.
6. `NETWORK-SECURITY-REVIEW.md` after CloudFront and origin hardening.
7. `CLEANUP.md` before deleting AWS resources.

## Recommended Tooling

For Codex guidance, install Agent Toolkit for AWS using the AWS quick start:

```text
https://docs.aws.amazon.com/agent-toolkit/latest/userguide/quick-start.html
```

For Codex, AWS documents:

```bash
codex plugin marketplace add aws/agent-toolkit-for-aws
```

Then launch Codex and use `/plugins` to install `aws-core`.

Install `cfn-lint` before CloudFormation validation:

```bash
python3 -m pip install cfn-lint
# or on macOS:
brew install cfn-lint
```

Use `cfn-lint` before AWS `cloudformation validate-template` and before creating any stack.

## Source Repository Rule

For CodePipeline, the application source repository root must be the contents of `appointments-app/`:

```text
Dockerfile
manage.py
requirements.txt
requirements-dev.txt
buildspecs/
manifests/
appointments/
hairdresser_django/
rds-global-bundle.pem
```

Do not push this whole package root as the application source unless you intentionally redesign the CodeBuild buildspec paths and Docker build context.

## Demo Boundary

The final hardened demo path is:

```text
Browser HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> Kubernetes Ingress -> ClusterIP Service -> pod IP targets
```

This is not end-to-end TLS. CloudFront provides browser-facing HTTPS. The ALB and pods remain HTTP for this affordable demo. After origin hardening, direct ALB access must not return the app.

## Safety Rules

- Do not use AWS root credentials.
- Do not commit credentials, kubeconfig files, `.env` files, database passwords, generated secrets, or raw CloudFront origin-header values.
- Keep local parameter files outside this package, preferably under `/tmp`.
- Keep `PipelineDeployMode=ManualApproval` for first launch.
- Create Kubernetes secrets without printing their values.
- Run read-only checks before AWS mutations.
- Get explicit approval before creating, updating, approving, deploying, or deleting AWS resources.
- Tear down promptly after the demo.

## Production Hardening Highlights

- Gunicorn runtime instead of Django `runserver`.
- Non-root container UID/GID `10001`.
- Kubernetes `runAsNonRoot`, dropped capabilities, no privilege escalation, and `RuntimeDefault` seccomp.
- PyMySQL with the RDS global CA bundle.
- Kubernetes `ClusterIP` Service behind ALB Ingress with pod IP targets.
- Optional CloudFront default-domain HTTPS companion stack.
- SSM-backed origin-header hardening and CloudFront origin-facing prefix-list support.
