# Phase 10 Appointments Scheduler Production Migration Package

This package is a portable migration version of the Phase/Lab 10 appointments scheduler app for use in a personal AWS account.

It includes the Django application, production Dockerfile, CodeBuild buildspecs, Kubernetes manifests, AWS CloudFormation IaC, and production migration documentation. Lab-only values are either parameterized in staged files or documented as values you must replace.

## Architectural Takeaway

This appointments app does not need Kubernetes because of the scheduling workflow's complexity. It uses Kubernetes as a learning vehicle for enterprise deployment patterns: pod replacement, node recovery, unhealthy target routing, rolling deploys, rollback, scaling, private workloads, origin hardening, and teardown discipline.

The hardened demo path is:

```text
Browser -> HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> pods
```

This is not end-to-end TLS. Kubernetes also does not replace database continuity, backups, DNS/failover planning, monitoring, alarms, incident runbooks, or cost controls. For a small real scheduling app, simpler AWS services may be more appropriate.

The `scripts/config.example` file is a sanitized kubeconfig shape. Generate the real kubeconfig in your account with `aws eks update-kubeconfig --name "$EKS_CLUSTER_NAME" --region "$AWS_REGION"` instead of committing or packaging local auth state.

Start with:

1. `DEPLOYMENT.md` for the chronological migration path.
2. `IAM-PERMISSIONS.md` for permissions by AWS service.
3. `MIGRATION-NOTES.md` for differences from the lab package.
4. `CLEANUP.md` before deleting AWS resources.
5. `iac/cloudformation/README.md` for CloudFormation stack details.

Do not deploy this package directly without replacing placeholders such as `ACCOUNT_ID`, `AWS_REGION`, `ECR_REPOSITORY`, `RDS_ENDPOINT`, `DB_IAM_USER`, `DB_NAME`, `DYNAMODB_ANNOUNCEMENTS_TABLE`, `ALLOWED_HOSTS`, `CSRF_TRUSTED_ORIGINS`, HTTPS/ALB values, and the `TAG_*` values used by the ALB ingress.

For CodePipeline, the source repository root should be the contents of `appointments-app/`. The migration docs and IaC stay outside that application repository unless you also adjust the CodeBuild `BuildSpec` paths and Docker build context.

When this package is used from the student handoff repository, use the surrounding walkthrough and teardown scripts for the guided cleanup path. Keep teardown dry-run-first, delete Kubernetes-managed resources before the shared infrastructure, and confirm account identity, Region, stack name, and cost-bearing resources before deleting anything.

The production package uses Gunicorn for the container runtime, a multi-stage Alpine Dockerfile, a non-root app user with UID/GID `10001`, PyMySQL as the MySQLdb compatibility shim, and the Amazon RDS global CA bundle for verified RDS TLS. Runtime dependencies were refreshed against PyPI during the hardening pass: Django stays on the current 5.2 LTS line for the Python runtime, while `django-iam-dbauth`, `PyMySQL`, `boto3`, and `gunicorn` were updated to current compatible versions and the Django test suite passed. The runtime image avoids the previous MariaDB/MySQL, Perl, and PAM package path that generated ECR findings. The package also includes a lightweight `/healthz` endpoint for Kubernetes and ALB checks, a `ClusterIP` service behind ALB Ingress, a configurable `PipelineDeployMode`, an in-cluster RDS bootstrap job template for the private database, and a `DeployPods` migration job that runs `manage.py migrate --noinput` before the web deployment rollout. Keep `PipelineDeployMode=ManualApproval` for first launch until post-stack setup is complete; use `PipelineDeployMode=AutoDeploy` for the proven pipeline so `DeployPods` runs immediately after `BuildImage`. `BuildImage` pushes a commit-specific ECR image tag, and `DeployPods` renders that same tag into the migration job and web deployment manifests so each pipeline run deploys the exact image it built.

The web manifests are tuned for cleaner ALB rerouting during planned pod or node disruption: two replicas, zero-unavailable rolling updates, topology spreading across worker nodes, a PodDisruptionBudget, faster `/healthz` readiness and ALB health checks, a 30-second ALB deregistration delay, and a 30-second `preStop` drain window. The hostname spread rule requires two node domains with `minDomains: 2` and uses `matchLabelKeys: pod-template-hash` so each new ReplicaSet spreads across nodes instead of co-locating after a rollout. For the strongest ALB readiness behavior, label the `default` namespace with `elbv2.k8s.aws/pod-readiness-gate-inject=enabled` as an admin pre-step before recreating app pods; this is intentionally not performed by the namespace-scoped DeployPods role.

HTTPS is optional and parameter-driven for an affordable demo. Leave `AlbCertificateArn` blank for HTTP-only first launch. For no-custom-domain HTTPS, deploy the packaged `iac/cloudformation/cloudfront-default-https.yaml` companion stack after the ALB DNS exists, set `OriginDnsName=<ALB_DNS>`, keep `PriceClass=PriceClass_100`, generate a random `OriginAccessHeaderValue` outside the repo, and store that same value in SSM Parameter Store as a `SecureString`. Add the origin-header name, the SSM parameter name as `CloudFrontOriginHeaderValue`, and the regional CloudFront origin-facing prefix list ID to the main app stack parameters before rerunning `DeployPods`. This gives a browser URL like `https://...cloudfront.net` without Route 53 or an ACM certificate, while making direct ALB access fail at the security group layer or at the ALB listener instead of reaching the app. For polished ALB-native HTTPS later, create or reuse a public ACM certificate in the deployment Region, set `AlbCertificateArn`, point a demo domain or subdomain to the ALB, and let `DeployPods` render the HTTPS listener, modern ALB TLS policy, and HTTP-to-HTTPS redirect annotations. Public ACM certificates do not add the main recurring cost; the existing ALB remains the main public-routing cost driver. Use `AlbInboundCidrs` only when CloudFront origin hardening is not enabled.

The web container manifest enforces the non-root runtime with `runAsNonRoot`, explicit UID/GID `10001`, `allowPrivilegeEscalation: false`, dropped capabilities, and `RuntimeDefault` seccomp. The RDS CA bundle is packaged at `/app/rds-global-bundle.pem` and can be overridden with the `RDS_CA_BUNDLE` environment variable if a future deployment needs a different trust bundle.

The first-launch `DjangoAllowedHosts=*` parameter is a temporary ALB discovery setting, not a final hardening value. After the ALB DNS name, CloudFront domain, or custom domain is known, replace broad host and CSRF values with the actual hostname/origin. For the no-custom-domain CloudFront path, `DeployPods` enables secure Django cookies when `DjangoCsrfTrustedOrigins` includes `cloudfront.net` but does not enable Django's own SSL redirect, because CloudFront handles viewer HTTP-to-HTTPS redirection while the origin connection to the ALB remains HTTP. This is not end-to-end TLS: the intended demo path is `Browser -> HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> pods`. The CloudFront origin header is a demo origin-bypass guard; CloudFormation `NoEcho` masks the companion stack parameter, while `DeployPods` reads the same value from SSM Parameter Store instead of storing it as a plaintext CodeBuild project environment variable. For ALB-native HTTPS, `DeployPods` enables secure Django cookies and app SSL redirect when `AlbCertificateArn` is supplied. Keep `DjangoSecureHstsSeconds=0` until the HTTPS domain is stable. Manifest environment values are quoted so wildcard and URL values render as valid Kubernetes YAML during the CodeBuild `DeployPods` stage.

The appointment booking flow includes backend schedule protection in addition to the visible disabled time buttons. `appointments-app/appointments/models.py` defines `AppointmentSlot`, a thirty-minute slot lock table with a unique constraint on hairdresser and slot start time. `appointments-app/appointments/views.py` creates appointments and slot locks inside one database transaction, rejects off-grid direct posts, and returns a friendly message if a time is booked concurrently.
