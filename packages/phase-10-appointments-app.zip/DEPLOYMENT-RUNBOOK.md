# Student Deployment Runbook

This runbook is the self-contained deployment path for the Phase 10 production package. It is written for a student-owned AWS account or an approved AWS sandbox and is designed to be followed by a human with help from an AI assistant.

Use this package for deployment:

```text
phase-10-appointments-app.zip
```

Use the lab package only for comparison:

```text
phase-10-appointments-app-lab.zip
```

If this package is used from the larger student handoff repository, the outer `WALKTHROUGH.md` and `WALKTHROUGH-CHECKLIST.md` remain the easiest guided path. This file exists so the production zip can also stand on its own.

## Deployment Goal

Deploy the appointments scheduler into AWS using the production-style Phase 10 architecture:

```text
CodeCommit or GitHub source
-> CodePipeline
-> CodeBuild UnitTest
-> CodeBuild BuildImage
-> ECR
-> Manual ApproveDeploy gate for first launch
-> CodeBuild DeployPods
-> EKS private worker nodes
-> Kubernetes ClusterIP Service
-> AWS Load Balancer Controller-managed ALB
-> optional CloudFront default-domain HTTPS companion stack
-> private RDS MySQL
-> DynamoDB announcements table
```

The final affordable HTTPS demo path is:

```text
Browser -> HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> pods
```

This is not end-to-end TLS. CloudFront provides browser-facing HTTPS. The ALB-to-pod path remains HTTP for this demo.

## Architectural Takeaway

This scheduling app does not require Kubernetes because of app complexity. In a real small production environment, a simpler service such as Elastic Beanstalk, ECS Fargate, App Runner, Lambda/API Gateway, or a small EC2 deployment could be cheaper and easier to operate.

This package intentionally uses Kubernetes as a learning vehicle. It demonstrates EKS, private worker nodes, ALB Ingress, pod-IP target groups, health checks, rolling deployments, pod replacement, security group boundaries, CI/CD, runtime hardening, CloudFront front-door HTTPS, origin-bypass hardening, and teardown discipline.

Kubernetes helps demonstrate:

- Restarting or replacing failed pods.
- Rescheduling pods when a worker node is unhealthy.
- Routing only to healthy pod IP targets through the ALB target group.
- Rolling deployments and rollback behavior.
- Scaling patterns and failure isolation.

Kubernetes does not automatically solve:

- Total network outage.
- Database continuity.
- Backups and restore testing.
- DNS failover.
- Monitoring and alerting.
- Incident response.
- Cost controls.

## Safety Rules

- Do not use AWS root credentials.
- Do not paste secrets into chat.
- Do not commit AWS credentials, `.env` files, kubeconfig files, database passwords, generated Django secret keys, private keys, or raw CloudFront origin-header values.
- Keep local parameter files and secret-bearing files outside Git, preferably under `/tmp`.
- Keep `PipelineDeployMode=ManualApproval` for the first launch.
- Run read-only checks before any AWS mutation.
- Get explicit approval before creating, updating, approving, deploying, or deleting AWS resources.
- Treat CloudFormation `NoEcho` as masking, not full secret storage.
- Tear down promptly after the demo.

## 1. Confirm Local Readiness

Read these package files first:

```text
README.md
AI-ASSISTED-DEPLOYMENT-GUIDE.md
DEPLOYMENT.md
IAM-PERMISSIONS.md
MIGRATION-NOTES.md
PACKAGE-COMPARISON.md
NETWORK-SECURITY-REVIEW.md
CLEANUP.md
iac/cloudformation/README.md
iac/cloudformation/post-deploy.md
```

Check local tools:

```bash
aws --version
git --version
unzip -v
jq --version
openssl version
kubectl version --client
helm version
cfn-lint --version
```

Optional troubleshooting tools:

```bash
mysql --version
docker --version
```

Stop if required tools are missing.

## 2. Validate The Package

From the directory that contains the zip files:

```bash
unzip -t phase-10-appointments-app.zip
unzip -t phase-10-appointments-app-lab.zip
```

Inspect the production zip without deploying it:

```bash
unzip -l phase-10-appointments-app.zip
```

After extraction, confirm the production package contains:

```text
appointments-app/
appointments-app/Dockerfile
appointments-app/buildspecs/
appointments-app/manifests/
iac/cloudformation/appointments-production.yaml
iac/cloudformation/cloudfront-default-https.yaml
DEPLOYMENT-RUNBOOK.md
NETWORK-SECURITY-REVIEW.md
CLEANUP.md
```

Stop if package integrity fails or required files are missing.

## 3. Choose Deployment Values

Choose these before deploying:

- AWS profile: `TBD_STUDENT_PROFILE`
- AWS Region: normally `us-west-1`
- Main stack name: `appointments-prod`
- CloudFront companion stack name: `appointments-prod-cloudfront-https`
- Source provider: `CodeCommit` or `GitHub`
- Source branch: `main`
- CodeCommit repository name: `appointments-app` if using CodeCommit
- GitHub repository ID: `TBD_GITHUB_OWNER/TBD_REPO` if using GitHub
- CodeStar connection ARN: `TBD_CODESTAR_CONNECTION_ARN` if using GitHub
- EKS cluster name: `appointments-prod`
- ECR repository name: `appointments-app`
- RDS instance identifier: `appointments-prod-mysql`
- RDS database name: `django_appointments`
- RDS app user: `appointments_web`
- DynamoDB table name: `prod-appointments-announcements`
- Owner tag value: `Student`
- Repo tag value: a non-secret student repo label

For the first deployment, keep:

```text
PipelineDeployMode=ManualApproval
AlbCertificateArn=
DjangoSecureHstsSeconds=0
```

Do not use a custom domain, Route 53, custom ACM certificate, WAF, service mesh, pod-level TLS, or mTLS unless those are explicitly approved as later production hardening.

## 4. Run AWS Preflight Checks

Set local variables in your shell. Do not commit these values:

```bash
export AWS_PROFILE=TBD_STUDENT_PROFILE
export AWS_REGION=us-west-1
export AWS_DEFAULT_REGION="$AWS_REGION"
export STACK_NAME=appointments-prod
```

Run identity checks:

```bash
aws sts get-caller-identity --profile "$AWS_PROFILE" --output table
aws configure list --profile "$AWS_PROFILE"
aws configure get region --profile "$AWS_PROFILE"
```

Run read-only collision checks:

```bash
aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$AWS_REGION" --profile "$AWS_PROFILE"
aws eks list-clusters --region "$AWS_REGION" --profile "$AWS_PROFILE"
aws ecr describe-repositories --repository-names appointments-app --region "$AWS_REGION" --profile "$AWS_PROFILE"
aws rds describe-db-instances --db-instance-identifier appointments-prod-mysql --region "$AWS_REGION" --profile "$AWS_PROFILE"
aws dynamodb describe-table --table-name prod-appointments-announcements --region "$AWS_REGION" --profile "$AWS_PROFILE"
aws codepipeline get-pipeline --name appointments-prod-ApplicationPipeline --region "$AWS_REGION" --profile "$AWS_PROFILE"
```

Some of these commands should return "not found" before a clean first deployment. Stop if they reveal resources you did not expect.

Before continuing, confirm:

- The AWS account is correct.
- The user is not root.
- A budget or billing alert exists.
- The selected Region is correct.
- Billable resources are understood.

## 5. Extract The Production Package

Extract outside the repository:

```bash
mkdir -p /tmp/appointments-phase-10-prod
unzip phase-10-appointments-app.zip -d /tmp/appointments-phase-10-prod
cd /tmp/appointments-phase-10-prod
find . -maxdepth 4 -type f | sort
```

Do not extract package contents into a tracked Git repository unless you are intentionally rebuilding a package.

## 6. Prepare The Application Source Repository

The application source repository root must be the contents of:

```text
/tmp/appointments-phase-10-prod/appointments-app/
```

Do not push the entire production package root as the application source unless you intentionally redesign the CodeBuild buildspec paths and Docker build context.

### CodeCommit Path

Create the repository only after approval:

```bash
aws codecommit create-repository \
  --repository-name appointments-app \
  --repository-description "Phase 10 production appointments app source" \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Push the app source root:

```bash
cd /tmp/appointments-phase-10-prod/appointments-app
git init -b main
git config user.name "Student Name"
git config user.email "student@example.invalid"
git add .
git commit -m "Add Phase 10 production appointments app"
git config credential.helper '!aws codecommit credential-helper $@'
git config credential.UseHttpPath true
git remote add origin https://git-codecommit.${AWS_REGION}.amazonaws.com/v1/repos/appointments-app
AWS_PROFILE="$AWS_PROFILE" AWS_REGION="$AWS_REGION" AWS_DEFAULT_REGION="$AWS_DEFAULT_REGION" git push -u origin main
```

### GitHub Path

If using GitHub, create a private repository for the contents of `appointments-app/`, then authorize a CodeStar connection in the AWS console. Set the CloudFormation parameters:

```text
SourceProvider=GitHub
GitHubFullRepositoryId=TBD_GITHUB_OWNER/TBD_REPO
CodeStarConnectionArn=TBD_CODESTAR_CONNECTION_ARN
SourceBranchName=main
```

## 7. Prepare CloudFormation Parameters

Create the parameter file outside Git:

```bash
cp /tmp/appointments-phase-10-prod/iac/cloudformation/parameters.example.json /tmp/appointments-prod-parameters.json
chmod 600 /tmp/appointments-prod-parameters.json
```

Edit `/tmp/appointments-prod-parameters.json` locally. Do not print the full file in chat or commit it.

Required updates normally include:

- `SourceProvider`
- `CodeCommitRepositoryName` or GitHub parameters
- `SourceBranchName`
- `DatabaseMasterPassword`
- `OwnerTagValue`
- `RepoTagValue`
- `DjangoAllowedHosts`
- `DjangoCsrfTrustedOrigins`
- `PipelineDeployMode=ManualApproval`

For the first launch, keep:

```text
CloudFrontOriginHeaderValue=
AlbSecurityGroupPrefixLists=
```

Those are enabled later during the CloudFront origin-hardening phase after the ALB exists.

## 8. Validate CloudFormation

Run local lint:

```bash
cd /tmp/appointments-phase-10-prod
cfn-lint -i W1030 W1011 -- iac/cloudformation/appointments-production.yaml
cfn-lint iac/cloudformation/cloudfront-default-https.yaml
```

Known non-blocking baseline warnings:

- `W1030` can appear for the optional empty `CodeStarConnectionArn` value.
- `W1011` can appear because the demo uses a local NoEcho password parameter instead of a dynamic secret reference.

Run AWS template validation:

```bash
aws cloudformation validate-template \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --template-body file://iac/cloudformation/appointments-production.yaml

aws cloudformation validate-template \
  --profile "$AWS_PROFILE" \
  --region "$AWS_REGION" \
  --template-body file://iac/cloudformation/cloudfront-default-https.yaml
```

Do not create the stack until validation results are reviewed.

## 9. Create The Main Stack After Approval

Before creating the stack, state:

- AWS profile
- AWS account identity
- AWS Region
- stack name
- source provider
- source repository
- expected billable resources
- rollback and teardown path

Create only after explicit approval:

```bash
aws cloudformation create-stack \
  --stack-name "$STACK_NAME" \
  --template-body file://iac/cloudformation/appointments-production.yaml \
  --parameters file:///tmp/appointments-prod-parameters.json \
  --capabilities CAPABILITY_IAM \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Wait for completion:

```bash
aws cloudformation wait stack-create-complete \
  --stack-name "$STACK_NAME" \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

If the stack fails, inspect failed events before retrying:

```bash
aws cloudformation describe-stack-events \
  --stack-name "$STACK_NAME" \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Do not immediately delete or retry a failed stack. Identify the root cause first.

## 10. Configure EKS And Kubernetes Prerequisites

After the stack reaches `CREATE_COMPLETE`, configure kubeconfig outside Git:

```bash
aws eks update-kubeconfig \
  --name appointments-prod \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE" \
  --kubeconfig /tmp/appointments-prod-kubeconfig

chmod 600 /tmp/appointments-prod-kubeconfig
```

Validate nodes and system pods:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get nodes -o wide
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get pods -A
```

Install or verify AWS Load Balancer Controller only after approval. Use the controller version and install method documented for the class or current AWS guidance.

Confirm:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get ingressclass
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig -n kube-system get deploy
```

Create the Django Kubernetes Secret without printing the value:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig \
  -n default create secret generic appointments-django \
  --from-literal=DJANGO_SECRET_KEY="<generated-value>"
```

Enable ALB readiness gate injection before app pods are created:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig \
  label namespace default elbv2.k8s.aws/pod-readiness-gate-inject=enabled --overwrite
```

Bootstrap private RDS from inside EKS using the package SQL and Job template. This mutates database users/schema and requires explicit approval. Keep privileged database credentials outside Git and remove temporary Kubernetes bootstrap materials after success.

## 11. Approve The First Pipeline Deploy

The first launch should pause at the manual `ApproveDeploy` action.

Check pipeline state:

```bash
aws codepipeline get-pipeline-state \
  --name appointments-prod-ApplicationPipeline \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Approve only after these prerequisites are complete:

- EKS nodes are ready.
- AWS Load Balancer Controller is installed and healthy.
- `appointments-django` Secret exists.
- RDS bootstrap completed successfully.
- Readiness-gate namespace label exists.

After approval, monitor CodePipeline and CodeBuild until `DeployPods` completes.

## 12. Validate ALB And Kubernetes

Check Kubernetes resources:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get deploy,job,svc,ingress,pdb -n default
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get pods -n default -o wide
```

Expected shape:

- Migration Job is complete.
- Web Deployment is `2/2`.
- Service is `ClusterIP`.
- Ingress class is `alb`.
- ALB target type is `ip`.
- Target group registers pod IPs, not public nodes.

Validate health through the ALB before adding CloudFront:

```bash
curl -I http://TBD_ALB_DNS_NAME/healthz
curl -I http://TBD_ALB_DNS_NAME/
```

Expected:

- `/healthz` returns `200`.
- `/` returns `200`.
- ALB target group shows healthy pod IP targets.

## 13. Validate Container Hardening

Confirm the production runtime is not Linux root:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig \
  -n default exec deploy/appointments-deployment -- id
```

Expected:

```text
uid=10001
gid=10001
```

Confirm Kubernetes security context:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig \
  -n default get deploy appointments-deployment -o yaml
```

Expected hardening:

- `runAsNonRoot: true`
- `runAsUser: 10001`
- `runAsGroup: 10001`
- `allowPrivilegeEscalation: false`
- capabilities drop `ALL`
- `seccompProfile: RuntimeDefault`

Review ECR scan results for the image that was actually deployed.

## 14. Add CloudFront HTTPS

This phase creates browser-facing HTTPS without a custom domain.

Generate a CloudFront origin-header value outside Git. Do not print it in chat or commit it.

Create a local companion-stack parameter file outside Git:

```text
/tmp/appointments-cloudfront-parameters.json
```

The companion stack should set:

```text
OriginDnsName=TBD_ALB_DNS_NAME
OriginAccessHeaderName=X-Origin-Verify
OriginAccessHeaderValue=<generated-value>
PriceClass=PriceClass_100
```

Deploy or update the companion stack only after approval:

```bash
aws cloudformation create-stack \
  --stack-name appointments-prod-cloudfront-https \
  --template-body file://iac/cloudformation/cloudfront-default-https.yaml \
  --parameters file:///tmp/appointments-cloudfront-parameters.json \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Validate:

```bash
curl -I http://TBD_CLOUDFRONT_DOMAIN/healthz
curl -I https://TBD_CLOUDFRONT_DOMAIN/healthz
curl -I https://TBD_CLOUDFRONT_DOMAIN/
```

Expected:

- CloudFront HTTP redirects to HTTPS.
- CloudFront HTTPS `/healthz` returns `200`.
- CloudFront HTTPS `/` returns `200`.

At this checkpoint, direct ALB access may still return the app. That is fixed in the next phase.

## 15. Harden Direct ALB Access

Goal:

```text
CloudFront works.
Direct ALB access from a normal laptop does not return the application.
```

Store the origin-header value in SSM Parameter Store as a `SecureString` outside this repo:

```bash
aws ssm put-parameter \
  --name /appointments/prod/cloudfront-origin-header-value \
  --type SecureString \
  --value "<generated-value>" \
  --overwrite \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Find the CloudFront origin-facing prefix list:

```bash
aws ec2 describe-managed-prefix-lists \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE" \
  --filters Name=prefix-list-name,Values=com.amazonaws.global.cloudfront.origin-facing
```

Check security group rule quota before applying the prefix list. The CloudFront origin-facing prefix list can consume significant rule quota.

Update the main stack parameters:

```text
DjangoCsrfTrustedOrigins=https://*.amazonaws.com,https://*.cloudfront.net
CloudFrontOriginHeaderName=X-Origin-Verify
CloudFrontOriginHeaderValue=/appointments/prod/cloudfront-origin-header-value
AlbSecurityGroupPrefixLists=<cloudfront-origin-facing-prefix-list-id>
```

Important: for the main stack, `CloudFrontOriginHeaderValue` should be the SSM parameter name, not the raw header value.

Update the main stack only after approval:

```bash
aws cloudformation update-stack \
  --stack-name "$STACK_NAME" \
  --template-body file://iac/cloudformation/appointments-production.yaml \
  --parameters file:///tmp/appointments-prod-parameters.json \
  --capabilities CAPABILITY_IAM \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Rerun or approve `DeployPods` so the Ingress and app environment are refreshed.

Validate:

```bash
curl -I https://TBD_CLOUDFRONT_DOMAIN/healthz
curl -I https://TBD_CLOUDFRONT_DOMAIN/
curl -I http://TBD_ALB_DNS_NAME/healthz
```

Expected:

- CloudFront HTTPS `/healthz` returns `200`.
- CloudFront HTTPS `/` returns `200`.
- Direct ALB `/healthz` times out, returns `403`, or returns a safe fallback.
- Direct ALB access must not return the application.
- CodeBuild shows `CLOUDFRONT_ORIGIN_HEADER_VALUE` as `PARAMETER_STORE`, not `PLAINTEXT`.

## 16. Run Network Security Review

Use:

```text
NETWORK-SECURITY-REVIEW.md
```

Confirm:

- Viewer traffic uses HTTPS to CloudFront.
- CloudFront-to-ALB traffic is HTTP for this demo.
- ALB-to-pod traffic is HTTP for this demo.
- The architecture is not end-to-end TLS.
- Direct ALB bypass is blocked or denied after hardening.
- Kubernetes Service remains `ClusterIP`.
- Pods and worker nodes are not publicly reachable.
- RDS is private and not publicly accessible.
- RDS writes still work from the app path.
- The app does not use forwarded headers for authorization decisions.
- Health checks do not expose secrets or stack traces.
- Logs do not print secrets.

## 17. Optional Application Workflow Validation

Only mutate app data after approval.

Suggested checks:

- Load the CloudFront HTTPS URL.
- Create a test appointment.
- Confirm the write succeeds.
- Refresh and confirm the appointment persists.
- Delete or clear test data if desired.

Do not store real personal data in the demo database.

## 18. Rollback And Cleanup

For failed Kubernetes rollouts:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig \
  -n default rollout status deploy/appointments-deployment

kubectl --kubeconfig /tmp/appointments-prod-kubeconfig \
  -n default rollout undo deploy/appointments-deployment
```

For failed CloudFormation changes, inspect stack events before retrying.

Before deleting the main stack, delete Kubernetes-managed application resources first so the AWS Load Balancer Controller can remove the ALB cleanly:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig -n default delete ingress appointments-ingress
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig -n default delete svc appointments-service
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig -n default delete deploy appointments-deployment
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig -n default delete job appointments-migrate --ignore-not-found
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig -n default delete pdb appointments-pdb --ignore-not-found
```

Then delete the CloudFront companion stack and main stack after approval:

```bash
aws cloudformation delete-stack \
  --stack-name appointments-prod-cloudfront-https \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"

aws cloudformation delete-stack \
  --stack-name "$STACK_NAME" \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Remove the SSM origin-header parameter after approval:

```bash
aws ssm delete-parameter \
  --name /appointments/prod/cloudfront-origin-header-value \
  --region "$AWS_REGION" \
  --profile "$AWS_PROFILE"
```

Review `CLEANUP.md` for remaining manual cleanup checks.

## 19. Completion Criteria

Deployment is complete when:

- Main stack is stable.
- Source pipeline has succeeded.
- Migration Job completed.
- Web Deployment is `2/2`.
- Service is `ClusterIP`.
- ALB target group has healthy pod IP targets.
- CloudFront HTTPS `/healthz` returns `200`.
- CloudFront HTTPS `/` returns `200`.
- Direct ALB access no longer returns the app after origin hardening.
- Pods run as UID/GID `10001`.
- ECR scan results are reviewed.
- RDS is private and app writes work.
- No secrets are committed or printed.
- Teardown path is understood and tested at least in dry-run/planning form.

The demo should be torn down promptly after presentation or testing to avoid ongoing charges.
