# Cleanup

Use cleanup carefully. Delete Kubernetes-managed application resources before shared infrastructure, and verify profile, Region, stack name, cluster name, and account identity before every command.

This architecture is intentionally bigger than a small scheduling app needs, so cleanup is part of the learning objective. EKS, worker nodes, NAT Gateway, ALB, RDS, public IPv4 addresses, logs, images, and retained snapshots can keep billing after the demo if they are left behind.

If this package is being used from the student handoff repository, start with `scripts/12-teardown-plan.sh` there. That helper is dry-run-first and prints the intended cleanup scope before any real deletion.

## What The Helper Cleans Up

The cleanup order should be:

1. Confirms AWS identity.
2. Updates a temporary kubeconfig outside the repo/package.
3. Deletes Kubernetes app resources: Ingress, Service, Deployment, PodDisruptionBudget, migration Job, ServiceAccount, and `appointments-django` Secret.
4. Waits for the AWS Load Balancer Controller to remove the ingress-managed ALB.
5. Deletes the optional CloudFront default-domain HTTPS companion stack, defaulting to `<stack-name>-cloudfront-https`.
6. Deletes the SSM origin-header parameter, defaulting to `/appointments/prod/cloudfront-origin-header-value`, unless `--skip-ssm-origin-header-parameter` is supplied.
7. Empties ECR images so the stack-owned repository can be deleted.
8. Empties stack-owned S3 artifact bucket contents and object versions.
9. Deletes the main CloudFormation stack and waits for completion.
10. Optionally deletes retained RDS manual snapshots with `--delete-rds-snapshots`.
11. Optionally deletes expected CodeBuild log groups with `--delete-log-groups`.
12. Optionally deletes the CodeCommit source repository with `--delete-source-repo`.

For the guided demo path, the typical names are:

- AWS profile: the student's chosen deployment profile
- Region: `us-west-1`
- Main stack: `appointments-prod`
- CloudFront companion stack: `appointments-prod-cloudfront-https`
- EKS cluster: `appointments-prod`
- ECR repository: `appointments-app`
- CodeCommit repository: `appointments-app`
- RDS instance identifier: `appointments-prod-mysql`
- CodeBuild project prefix: `appointments-prod`
- SSM origin-header parameter: `/appointments/prod/cloudfront-origin-header-value`

## Manual Cleanup Notes

If the helper stops because the ALB still exists, inspect the AWS Load Balancer Controller logs before deleting the EKS stack. Deleting the cluster before the controller removes the ALB can leave load balancer resources behind.

CodeCommit is retained by default so the application source is still available for relaunch. Add `--delete-source-repo` only when the source repository should be removed.

For a standard student cost cleanup, keep the source repository unless deletion is separately approved so a later relaunch can reuse the prepared app source.

The SSM origin-header parameter is deleted by default because it is created outside the main CloudFormation stack during CloudFront hardening. Add `--skip-ssm-origin-header-parameter` only if you intentionally want to retain that parameter for a later relaunch.

RDS and DynamoDB contain application data. Back up or intentionally discard data before teardown. Delete retained RDS snapshots only when retention is no longer needed.

Costs can continue from EKS clusters, node groups, NAT gateways, ALBs, RDS instances, EBS volumes, ECR image storage, CloudWatch Logs, CloudFront usage, public IPv4 addresses, and retained snapshots.
