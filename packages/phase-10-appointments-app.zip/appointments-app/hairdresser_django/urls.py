from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path


def healthz(_request):
    "Lightweight health check that avoids database and AWS service calls."
    return JsonResponse({"status": "ok"})


urlpatterns = [
    path("healthz", healthz, name="healthz"),
    path("", include("appointments.urls")),
    path("admin/", admin.site.urls),
]
