"Unit tests for appointments"
from datetime import datetime
from zoneinfo import ZoneInfo
from unittest.mock import patch

from django.test import TestCase
from django.urls import reverse

from .models import Appointment, AppointmentSlot

SERVICE_HAIRCUT = 1
SERVICE_HAIR_COLORING = 2
SERVICE_SHAMPOO = 3
HAIRDRESSER_1 = 1

#  pylint: disable=invalid-name, unused-argument
def mock_scan(TableName):
    "Mock the DynamoDB scan"
    return {
            "Items" : [
                {
                    "Contents": {
                        "S": "Test announcement"
                    }
                }
            ]
        }

@patch('appointments.views.dynamodb.scan', mock_scan)
class AppointmentsIndexViewTests(TestCase):
    "Tests for the index view"

    def test_index(self):
        "Test the response when a service is selected"
        response = self.client.get(reverse("index"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Haircut")

    @patch("django.utils.timezone.now")
    def test_index_hairdresser(self, mock_timezone):
        """Test selecting a service & hairdresser returns dates.
        Then create a midday appointment."""
        # Mock the current time for consistent results.
        fake_date = datetime(2010, 1, 1, 10, 0, tzinfo=ZoneInfo("America/Los_Angeles"))
        mock_timezone.return_value = fake_date

        # Select a service and hairdresser.
        response = self.client.get(
            reverse("index-hairdresser", args=(SERVICE_HAIRCUT, HAIRDRESSER_1))
        )
        # Grab the first offered date.
        first_date = response.context["dates_all"][0][1]

        response = self.client.get(
            reverse("index-date", args=(SERVICE_HAIRCUT, HAIRDRESSER_1, first_date))
        )
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Time")

        # Remember the initial count of available times.
        available_before = response.context["start_times_available_count"]

        # Book an appointment for midday.
        appt_time = "12:00"

        # Create an appointment.
        response = self.client.post(
            reverse("create"),
            {
                "service": SERVICE_HAIRCUT,
                "hairdresser": HAIRDRESSER_1,
                "date": first_date,
                "appointment_time": appt_time,
                "customer_contact": "+49123456789",
            },
        )

        # Test that the time is no longer available.
        response = self.client.get(
            reverse("index-date", args=(SERVICE_HAIRCUT, HAIRDRESSER_1, first_date))
        )
        # Build a list of the blocked times.
        blocked = [
            t["time_formatted"]
            for t in response.context["start_times_all"]
            if t["is_blocked"]
        ]
        assert appt_time in blocked, "Blocked time not found"

        # Test that the number of available appointments has been reduced.
        available_after = response.context["start_times_available_count"]
        assert available_after < available_before, "Available count not decremented"

    def test_announcements(self):
        "Test announcements are loaded"
        response = self.client.get(reverse("index"))
        assert response.context["announcements"][0] == "Test announcement"

    @patch("django.utils.timezone.now")
    def test_create_locks_appointment_slots(self, mock_timezone):
        "Test an appointment creates database-backed schedule locks"
        fake_date = datetime(2010, 1, 1, 8, 0, tzinfo=ZoneInfo("America/Los_Angeles"))
        mock_timezone.return_value = fake_date

        self.client.post(
            reverse("create"),
            {
                "service": SERVICE_HAIRCUT,
                "hairdresser": HAIRDRESSER_1,
                "date": "20100101",
                "appointment_time": "12:00",
                "customer_contact": "+49123456789",
            },
        )

        self.assertEqual(Appointment.objects.count(), 1)
        self.assertEqual(AppointmentSlot.objects.count(), 2)

    @patch("django.utils.timezone.now")
    def test_create_rejects_exact_double_booking(self, mock_timezone):
        "Test the backend rejects two appointments for the same slot"
        fake_date = datetime(2010, 1, 1, 8, 0, tzinfo=ZoneInfo("America/Los_Angeles"))
        mock_timezone.return_value = fake_date

        payload = {
            "service": SERVICE_HAIRCUT,
            "hairdresser": HAIRDRESSER_1,
            "date": "20100101",
            "appointment_time": "12:00",
            "customer_contact": "+49123456789",
        }
        self.client.post(reverse("create"), payload)
        self.client.post(reverse("create"), payload)

        self.assertEqual(Appointment.objects.count(), 1)
        self.assertEqual(AppointmentSlot.objects.count(), 2)

    @patch("django.utils.timezone.now")
    def test_create_rejects_overlapping_booking(self, mock_timezone):
        "Test a longer appointment blocks shorter appointments inside its range"
        fake_date = datetime(2010, 1, 1, 8, 0, tzinfo=ZoneInfo("America/Los_Angeles"))
        mock_timezone.return_value = fake_date

        self.client.post(
            reverse("create"),
            {
                "service": SERVICE_HAIR_COLORING,
                "hairdresser": HAIRDRESSER_1,
                "date": "20100101",
                "appointment_time": "12:00",
                "customer_contact": "+49123456789",
            },
        )
        self.client.post(
            reverse("create"),
            {
                "service": SERVICE_SHAMPOO,
                "hairdresser": HAIRDRESSER_1,
                "date": "20100101",
                "appointment_time": "12:30",
                "customer_contact": "+49123456789",
            },
        )

        self.assertEqual(Appointment.objects.count(), 1)
        self.assertEqual(AppointmentSlot.objects.count(), 4)

    @patch("django.utils.timezone.now")
    def test_create_allows_adjacent_booking(self, mock_timezone):
        "Test the backend allows a booking that starts after another one ends"
        fake_date = datetime(2010, 1, 1, 8, 0, tzinfo=ZoneInfo("America/Los_Angeles"))
        mock_timezone.return_value = fake_date

        self.client.post(
            reverse("create"),
            {
                "service": SERVICE_HAIRCUT,
                "hairdresser": HAIRDRESSER_1,
                "date": "20100101",
                "appointment_time": "12:00",
                "customer_contact": "+49123456789",
            },
        )
        self.client.post(
            reverse("create"),
            {
                "service": SERVICE_SHAMPOO,
                "hairdresser": HAIRDRESSER_1,
                "date": "20100101",
                "appointment_time": "13:00",
                "customer_contact": "+49123456789",
            },
        )

        self.assertEqual(Appointment.objects.count(), 2)
        self.assertEqual(AppointmentSlot.objects.count(), 3)

    @patch("django.utils.timezone.now")
    def test_create_rejects_off_grid_time(self, mock_timezone):
        "Test direct posts cannot bypass the visible thirty-minute grid"
        fake_date = datetime(2010, 1, 1, 8, 0, tzinfo=ZoneInfo("America/Los_Angeles"))
        mock_timezone.return_value = fake_date

        self.client.post(
            reverse("create"),
            {
                "service": SERVICE_HAIRCUT,
                "hairdresser": HAIRDRESSER_1,
                "date": "20100101",
                "appointment_time": "12:15",
                "customer_contact": "+49123456789",
            },
        )

        self.assertEqual(Appointment.objects.count(), 0)
        self.assertEqual(AppointmentSlot.objects.count(), 0)
