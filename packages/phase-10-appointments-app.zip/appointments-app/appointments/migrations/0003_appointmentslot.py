import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("appointments", "0002_populate"),
    ]

    operations = [
        migrations.CreateModel(
            name="AppointmentSlot",
            fields=[
                ("slot_id", models.AutoField(primary_key=True, serialize=False)),
                ("slot_start", models.DateTimeField()),
                (
                    "appointment",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="appointments.appointment",
                    ),
                ),
                (
                    "hairdresser",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        to="appointments.hairdresser",
                    ),
                ),
            ],
            options={
                "constraints": [
                    models.UniqueConstraint(
                        fields=("hairdresser", "slot_start"),
                        name="unique_hairdresser_slot_start",
                    )
                ],
            },
        ),
    ]
