# IAM Permissions

Use least privilege and scope resources to your account, region, repository, cluster, tables, and databases.

## Human Or Deployment Administrator

Required areas:

- CloudFormation: create, update, describe, and delete stacks and stack resources.
- IAM: create and pass roles for CodeBuild, CodePipeline, EKS cluster, EKS nodes, and AWS Load Balancer Controller.
- ECR: create repository, set repository policies, push and pull images.
- EKS: create/update cluster, node groups, access entries or aws-auth mappings.
- EC2/VPC/ELB: create or reference VPC, subnets, security groups, route tables, load balancers, listeners, and target groups.
- RDS: create or reference MySQL database, security groups, subnet groups, and IAM DB authentication.
- DynamoDB: create or reference announcements table.
- CodeBuild/CodePipeline: create projects, pipelines, artifacts, and service roles.
- S3: create and access the CodePipeline artifact bucket.
- CloudWatch Logs: read build and application logs.

When deploying `iac/cloudformation/appointments-production.yaml`, the operator needs `CAPABILITY_IAM` because the stack creates IAM roles and inline policies. The template does not assign fixed IAM role names.

## CodeBuild Unit Test Role

The unit-test stage should not have EKS or ECR permissions. It only needs:

- CloudWatch Logs write access.
- CodePipeline artifact bucket read/write access.

## CodeBuild Image Build Role

Typical permissions:

- `ecr:GetAuthorizationToken`
- `ecr:BatchCheckLayerAvailability`
- `ecr:InitiateLayerUpload`
- `ecr:UploadLayerPart`
- `ecr:CompleteLayerUpload`
- `ecr:PutImage`
- `ecr:BatchGetImage`
- `logs:CreateLogGroup`
- `logs:CreateLogStream`
- `logs:PutLogEvents`
- CodePipeline artifact bucket read/write access.

## CodeBuild DeployPods Role

Typical permissions:

- `eks:DescribeCluster`
- `sts:GetCallerIdentity`
- `logs:CreateLogGroup`
- `logs:CreateLogStream`
- `logs:PutLogEvents`
- Artifact bucket read access.
- Read-only ELB describe calls for deployment output/debugging.

The role must also be authorized inside Kubernetes through EKS access entries or the `aws-auth` ConfigMap. In this package, the DeployPods role uses an EKS access entry with `AmazonEKSEditPolicy` scoped to the `default` namespace, not cluster-admin. Kubernetes permissions must allow it to apply deployments, services, ingresses, service accounts, jobs, and related resources in the target namespace.

## CodePipeline Role

Typical permissions:

- `codebuild:StartBuild`
- `codebuild:BatchGetBuilds`
- Source provider permissions for GitHub, CodeCommit, or CodeStar Connections.
- S3 artifact bucket read/write.
- KMS key use if the artifact bucket is encrypted with a customer managed key.

## Application Pod Role

Prefer IRSA or EKS Pod Identity. The pod role needs:

- DynamoDB read access for the announcements table, including `dynamodb:Scan`.
- RDS IAM authentication permission such as `rds-db:connect` scoped to the database resource ID and database user.

## AWS Load Balancer Controller

Install with an IAM role scoped to the AWS Load Balancer Controller policy recommended by AWS for your EKS version. It needs permissions for ELBv2, EC2 security groups/subnets, ACM discovery when TLS is used, IAM service-linked role handling, WAF/Shield only if enabled, and tagging.

This package adds IAM conditions where practical for controller-owned resources:

- `iam:CreateServiceLinkedRole` is limited to the Elastic Load Balancing service-linked role.
- Security group tag and delete/update actions are tied to `elbv2.k8s.aws/cluster` request or resource tags.
- ALB and target group create/update/delete tag conditions require the same controller cluster tag where AWS supports those conditions.
- Target registration is scoped to Elastic Load Balancing target group ARNs.

## Least-Privilege Notes

- Keep UnitTest, BuildImage, and DeployPods on separate CodeBuild service roles.
- Only the DeployPods role should receive Kubernetes access.
- Only the BuildImage role should receive ECR image push permissions.
- Keep the application pod role scoped to the specific DynamoDB announcements table and RDS IAM database user.
- Re-run IAM Access Analyzer policy validation after stack creation if you further modify policies.
