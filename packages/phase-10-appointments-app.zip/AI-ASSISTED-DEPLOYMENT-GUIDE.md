# AI-Assisted Deployment Guide

Use this guide when deploying the production migration package with Codex or another AI coding/deployment assistant.

## Goal

Deploy the appointments scheduler app from GitHub or CodeCommit into a personal AWS account using the CloudFormation IaC and deployment docs in this package.

Architectural takeaway: this app does not require Kubernetes because of app complexity. Kubernetes is used here to teach pod recovery, node recovery, ALB target health, rolling deploys, scaling, private workloads, origin hardening, and teardown. The current demo boundary is `Browser -> HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> pods`, not end-to-end TLS, and it does not replace database continuity, backups, monitoring, DNS/failover planning, incident runbooks, or cost controls.

## Important Safety Rules

- Do not commit secrets, `.env` files, AWS credentials, kubeconfig files, database passwords, or generated tokens.
- Do not upload the real `scripts/config`; use `scripts/config.example` only as a shape reference.
- Confirm before creating billable AWS resources.
- Confirm before deleting AWS resources.
- Keep the application source repository root as the contents of `appointments-app/`.
- Keep the migration docs and CloudFormation files outside the application source repository unless you also update CodeBuild paths.

## Recommended Prompt For Codex Or Another AI Tool

```text
Use DEPLOYMENT.md, IAM-PERMISSIONS.md, and iac/cloudformation/README.md from this package.
Do not commit secrets or local auth files.
Deploy this app to my AWS account using AWS CloudFormation and GitHub source.
First inspect the files, then identify missing account-specific values, then ask me before creating billable AWS resources.
The app source repository root must be the contents of appointments-app/.
```

## Deployment Flow

1. Unzip the production package.
2. Read `README.md`, `DEPLOYMENT.md`, `IAM-PERMISSIONS.md`, and `iac/cloudformation/README.md`.
3. Create a GitHub repository or CodeCommit repository for the app source.
4. Push the contents of `appointments-app/` as the repository root.
5. Create or approve a GitHub CodeStar connection if using GitHub.
6. Copy `iac/cloudformation/parameters.example.json` to an account-specific parameter file.
7. Fill in account-specific CloudFormation parameters.
8. Deploy `iac/cloudformation/appointments-production.yaml`.
9. Wait for stack completion and collect stack outputs.
10. Generate kubeconfig with `aws eks update-kubeconfig`.
11. Install the AWS Load Balancer Controller with Helm.
12. Create the `appointments-django` Kubernetes Secret.
13. Bootstrap the RDS MySQL schema and IAM database user with `db-bootstrap.sql` and the in-cluster `iac/cloudformation/db-bootstrap-job.yml` template.
14. Keep `PipelineDeployMode=ManualApproval` until controller, secret, and RDS bootstrap checks are complete.
15. Switch to `PipelineDeployMode=AutoDeploy` after the first path is proven if the user wants a fully automatic pipeline.
16. Start or rerun CodePipeline if needed.
17. Verify pods, service, ingress, ALB DNS, RDS persistence, and DynamoDB announcements.

## Values The AI Should Ask The User For

- AWS region.
- Stack name.
- GitHub repository owner/name or CodeCommit repository name.
- GitHub CodeStar connection ARN if using GitHub.
- Source branch name.
- EKS cluster name.
- ECR repository name.
- VPC CIDR and subnet CIDRs.
- RDS instance class.
- RDS database name.
- RDS IAM app user.
- RDS master username.
- RDS master password, handled outside source control.
- DynamoDB announcements table name.
- Django allowed hosts.
- Django CSRF trusted origins.
- Desired kubectl version.
- Non-secret tag values for project, phase, environment, owner, repo, and managed-by metadata.

## Commands The AI May Run After Confirmation

Inspect package:

```bash
find . -maxdepth 4 -type f | sort
```

Deploy CloudFormation:

```bash
aws cloudformation create-stack \
  --stack-name appointments-prod \
  --template-body file://iac/cloudformation/appointments-production.yaml \
  --parameters file://iac/cloudformation/parameters.example.json \
  --capabilities CAPABILITY_IAM \
  --tags \
    Key=Project,Value=appointments \
    Key=Phase,Value=10 \
    Key=Environment,Value=prod \
    Key=Owner,Value=Student \
    Key=Repo,Value=student-appointments-scheduler \
    Key=ManagedBy,Value=phase10-runbook
```

Wait for stack:

```bash
aws cloudformation wait stack-create-complete --stack-name appointments-prod
aws cloudformation describe-stacks --stack-name appointments-prod
```

Configure Kubernetes access:

```bash
aws eks update-kubeconfig --name <EksClusterName> --region <AWS_REGION>
kubectl get nodes
```

Verify app deployment:

```bash
kubectl get pods
kubectl get service appointments-service
kubectl get ingress appointments-ingress
kubectl describe ingress appointments-ingress
```

If `PipelineDeployMode=ManualApproval`, approve the manual deployment gate after post-stack setup:

```bash
# Console path is preferred for students:
# CodePipeline -> appointments-prod-ApplicationPipeline -> ApproveDeploy -> Review -> Approve
```

## Manual Or Confirmation Required Steps

- GitHub CodeStar connection browser authorization.
- Choosing AWS region and CIDR ranges.
- Supplying the RDS master password.
- Creating the Django secret value.
- Running the in-cluster MySQL bootstrap job against private RDS.
- Choosing whether to keep `PipelineDeployMode=ManualApproval` or switch to `AutoDeploy` after post-stack setup.
- Confirming CloudFormation creation because it creates billable resources.
- Confirming cleanup because it can delete infrastructure and data.

## Source Repository Layout

The pipeline assumes this layout at the repository root:

```text
Dockerfile
buildspecs/
manifests/
manage.py
requirements.txt
requirements-dev.txt
appointments/
hairdresser_django/
```

This is the contents of `appointments-app/` in the package.

## Expected Pipeline

The CloudFormation stack creates a pipeline with these stages:

1. Source from GitHub or CodeCommit.
2. Unit tests with `buildspecs/buildspec_unittest.yml`.
3. Docker image build and ECR push with `buildspecs/buildspec_buildimage.yml`.
4. Optional manual approval when `PipelineDeployMode=ManualApproval`.
5. Kubernetes deployment with `buildspecs/buildspec_deploypods.yml`; in `AutoDeploy` mode this runs after image build.

## Troubleshooting Checklist

- If source fails, confirm the GitHub CodeStar connection is authorized and repository/branch names are correct.
- If image build fails, confirm CodeBuild privileged mode is enabled and ECR permissions exist.
- If deploy fails, confirm the DeployPods CodeBuild service role has namespace-scoped EKS access and `kubectl` was downloaded successfully.
- If pods cannot pull images, confirm the image URI rendered correctly and the ECR repository contains the image.
- If RDS connection fails, confirm security groups, IAM DB authentication, DB bootstrap SQL, and pod IAM role.
- If announcements fail, confirm the DynamoDB table name and pod role permissions.
- If ingress has no ALB, confirm AWS Load Balancer Controller is installed and its Pod Identity association is active.

## Cleanup

Before cleanup, read `CLEANUP.md`.

Back up RDS data and DynamoDB data first if needed. Then delete Kubernetes resources, wait for ALB cleanup, and delete the CloudFormation stack.
