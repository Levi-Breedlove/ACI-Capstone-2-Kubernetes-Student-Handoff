# AI-Assisted Deployment Guide

Use this guide when Codex or another AI assistant is helping a student deploy the production migration package.

The assistant should operate as a safety partner, not as an autopilot. The student owns the AWS account, budget, approvals, and any data deletion decisions.

For the full package-contained deployment path, start with `DEPLOYMENT-RUNBOOK.md`, track progress in `DEPLOYMENT-TASKS.md`, then use this guide as the AI-assistant operating checklist.

## Goal

Deploy the appointments scheduler app from GitHub or CodeCommit into a personal AWS account using the package CloudFormation templates, CodePipeline, CodeBuild, ECR, EKS, RDS MySQL, DynamoDB, AWS Load Balancer Controller, ALB Ingress, and optional CloudFront default-domain HTTPS.

The final demo path is:

```text
Browser HTTPS -> CloudFront -> HTTP -> ALB -> HTTP -> Kubernetes Ingress -> ClusterIP Service -> pod IP targets
```

This is not end-to-end TLS. CloudFront provides the public browser HTTPS endpoint. The ALB and pods remain HTTP for this demo. After origin hardening, direct ALB access must not return the application.

## Non-Negotiable Safety Rules

- Never use AWS root credentials.
- Never commit or print AWS access keys, session tokens, RDS passwords, Django secret keys, kubeconfig contents, private keys, or generated CloudFront origin-header values.
- Never ask the student to paste secrets into chat.
- Keep local parameter files, kubeconfig files, and generated secret material outside the package and outside Git.
- Use `/tmp/appointments-prod-parameters.json` for the main stack parameter file.
- Use the contents of `appointments-app/` as the application source repository root.
- Keep package docs and CloudFormation files outside the application source repository unless CodeBuild paths are intentionally redesigned.
- Run read-only checks before AWS mutations.
- Ask for explicit approval before create, update, deploy, approve, or delete commands.
- Treat CloudFront origin hardening values as sensitive. Do not run commands that dump full hardened Ingress annotations.

## Recommended Prompt

```text
Use README.md, DEPLOYMENT-RUNBOOK.md, DEPLOYMENT-TASKS.md, DEPLOYMENT.md, IAM-PERMISSIONS.md, iac/cloudformation/README.md, and NETWORK-SECURITY-REVIEW.md from this package.
Deploy only after checking AWS identity, Region, budget, package integrity, source layout, parameters, and template validation.
Keep the application source repository root as the contents of appointments-app/.
Keep local parameter files and secrets outside Git, preferably under /tmp.
Ask before creating, updating, approving, deploying, or deleting AWS resources.
Do not print or request secret values in chat.
After ALB validation, add CloudFront first, then harden direct ALB access, then run NETWORK-SECURITY-REVIEW.md.
```

## Phase 0: Inspect Package

Assistant tasks:

- List package files.
- Confirm `appointments-app/`, buildspecs, manifests, CloudFormation templates, cleanup docs, and network review exist.
- Confirm no local auth files are packaged.

Commands:

```bash
# From the surrounding handoff repository before extraction:
unzip -t packages/phase-10-appointments-app.zip

# From the extracted production package:
find . -maxdepth 4 -type f | sort
```

Evidence:

- `appointments-app/Dockerfile`
- `appointments-app/buildspecs/buildspec_unittest.yml`
- `appointments-app/buildspecs/buildspec_buildimage.yml`
- `appointments-app/buildspecs/buildspec_deploypods.yml`
- `appointments-app/manifests/appointments-deployment.yml`
- `appointments-app/manifests/appointments-service.yml`
- `appointments-app/manifests/appointments-ingress.yml`
- `iac/cloudformation/appointments-production.yaml`
- `iac/cloudformation/cloudfront-default-https.yaml`
- `NETWORK-SECURITY-REVIEW.md`

Stop if:

- Package integrity fails.
- Required deployment files are missing.

## Phase 1: Account, Cost, And Tool Gate

Ask the student for:

- AWS CLI profile name.
- AWS Region.
- Intended stack name.
- Whether a budget or billing alert exists.
- Whether this is their own account or an approved sandbox.

Install or confirm AI and validation tooling:

```bash
codex plugin marketplace add aws/agent-toolkit-for-aws
```

Then launch Codex and use `/plugins` to install `aws-core`. AWS documents this flow in the Agent Toolkit for AWS quick start:

```text
https://docs.aws.amazon.com/agent-toolkit/latest/userguide/quick-start.html
```

Install `cfn-lint` for CloudFormation validation:

```bash
python3 -m pip install cfn-lint
# or on macOS:
brew install cfn-lint
```

Read-only checks:

```bash
aws sts get-caller-identity --profile <student-profile>
aws configure list --profile <student-profile>
aws configure get region --profile <student-profile>
aws --version
git --version
jq --version
kubectl version --client
helm version
cfn-lint --version
```

Stop if:

- The student is using root.
- The profile points at the wrong account.
- The student has not approved expected costs.

## Phase 2: Source Repository

Ask the student to choose:

- CodeCommit, if available in the account.
- GitHub with CodeStar Connections, if CodeCommit is unavailable or not desired.

Application source root must be the contents of `appointments-app/`:

```text
Dockerfile
manage.py
requirements.txt
requirements-dev.txt
buildspecs/
manifests/
appointments/
hairdresser_django/
rds-global-bundle.pem
```

Do not push the whole package root as the app source.

Evidence:

- Source repository exists.
- Branch matches the CloudFormation parameter, usually `main`.
- Source root includes `Dockerfile`, `manage.py`, `buildspecs/`, and `manifests/`.
- No package docs, kubeconfig files, parameter files, or secrets are committed.

## Phase 3: Parameter File

Ask for non-secret values:

- Stack name.
- Region.
- Source provider.
- CodeCommit repository name or GitHub full repository ID.
- CodeStar connection ARN if using GitHub.
- Source branch.
- Database name.
- RDS IAM app user.
- RDS master username.
- DynamoDB announcements table name.
- Initial Django allowed hosts and CSRF trusted origins.
- Tag values.

Do not ask the student to paste:

- RDS master password.
- Django secret key.
- CloudFront origin-header value.

Create or update parameters outside Git:

```bash
cp iac/cloudformation/parameters.example.json /tmp/appointments-prod-parameters.json
chmod 600 /tmp/appointments-prod-parameters.json
```

Keep `PipelineDeployMode=ManualApproval` for the first launch.

Evidence:

- `/tmp/appointments-prod-parameters.json` exists.
- File mode is restrictive.
- Placeholder values are replaced.
- Secrets are not printed.

## Phase 4: Template Validation

Run local lint if available:

```bash
cfn-lint -i W1030 W1011 -- iac/cloudformation/appointments-production.yaml
cfn-lint iac/cloudformation/cloudfront-default-https.yaml
```

Run AWS validation:

```bash
aws cloudformation validate-template \
  --profile <student-profile> \
  --region <aws-region> \
  --template-body file://iac/cloudformation/appointments-production.yaml

aws cloudformation validate-template \
  --profile <student-profile> \
  --region <aws-region> \
  --template-body file://iac/cloudformation/cloudfront-default-https.yaml
```

Evidence:

- Main template validates.
- CloudFront template validates.
- IAM capability requirement is understood.

Stop if:

- Validation fails.
- Lint errors are present.

## Phase 5: Approval Gate For Main Stack

Before asking approval, state:

- AWS profile.
- AWS account ID.
- Region.
- Stack name.
- Template path.
- Parameter file path.
- Source provider.
- Billable resources: EKS, EC2 worker nodes, NAT Gateway, RDS, DynamoDB, ECR, CodePipeline, CodeBuild, S3 artifacts, CloudWatch Logs, and later ALB/CloudFront.
- Reversibility: teardown is possible, but retained snapshots/logs/repos may remain by choice.

Create only after explicit approval:

```bash
aws cloudformation create-stack \
  --profile <student-profile> \
  --region <aws-region> \
  --stack-name <stack-name> \
  --template-body file://iac/cloudformation/appointments-production.yaml \
  --parameters file:///tmp/appointments-prod-parameters.json \
  --capabilities CAPABILITY_IAM
```

Wait and inspect:

```bash
aws cloudformation wait stack-create-complete \
  --profile <student-profile> \
  --region <aws-region> \
  --stack-name <stack-name>

aws cloudformation describe-stacks \
  --profile <student-profile> \
  --region <aws-region> \
  --stack-name <stack-name> \
  --query 'Stacks[0].Outputs'
```

Stop if:

- Stack creation fails or rolls back.
- Events show quota, IAM, subnet, RDS, or EKS failures.

## Phase 6: Kubernetes Prerequisites

Create kubeconfig outside the package:

```bash
aws eks update-kubeconfig \
  --profile <student-profile> \
  --region <aws-region> \
  --name <EksClusterName> \
  --kubeconfig /tmp/appointments-prod-kubeconfig
chmod 600 /tmp/appointments-prod-kubeconfig
```

Then, after student approval:

- Install AWS Load Balancer Controller.
- Confirm controller pods are running.
- Confirm `alb` IngressClass exists.
- Create `appointments-django` Secret without printing the value.
- Label the default namespace for pod readiness gate injection.
- Bootstrap RDS from inside the cluster with `db-bootstrap.sql` and `iac/cloudformation/db-bootstrap-job.yml`.

Read-only validation:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get nodes -o wide
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get pods -n kube-system
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get ingressclass
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get secret appointments-django -n default
```

Stop if:

- Nodes are not ready.
- Controller is not running.
- Secret is missing.
- RDS bootstrap fails.

## Phase 7: First Pipeline Deploy

Keep `PipelineDeployMode=ManualApproval` until the following are true:

- AWS Load Balancer Controller is running.
- `appointments-django` Secret exists.
- RDS bootstrap completed.
- Source repository contains the correct app root.

Approve only after explicit student approval.

Expected pipeline stages:

1. Source from GitHub or CodeCommit.
2. Unit tests with `buildspecs/buildspec_unittest.yml`.
3. Docker image build and ECR push with `buildspecs/buildspec_buildimage.yml`.
4. Optional manual approval when `PipelineDeployMode=ManualApproval`.
5. Kubernetes deployment with `buildspecs/buildspec_deploypods.yml`.

Evidence:

- Pipeline reached `ApproveDeploy`.
- Student approved.
- `DeployPods` completed.
- Migration Job completed.

## Phase 8: ALB And App Validation

Read-only checks:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get deploy,svc,ingress,pods -n default -o wide
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get jobs -n default
```

Use ALB and target health checks without printing secrets.

Expected:

- Deployment is `2/2`.
- Service is `ClusterIP`.
- Ingress has an ALB address.
- Target group registers pod IPs.
- `/healthz` returns HTTP `200`.

Do not use `kubectl describe ingress` after origin hardening. The hardened Ingress condition annotation can contain the origin-header value.

## Phase 9: Container Hardening Validation

Validate:

- Dockerfile creates UID/GID `10001`.
- Container runs as `USER 10001:10001`.
- Kubernetes deployment sets `runAsNonRoot`, `runAsUser: 10001`, `runAsGroup: 10001`, `allowPrivilegeEscalation: false`, dropped capabilities, and `RuntimeDefault` seccomp.
- Runtime uses PyMySQL.
- RDS CA bundle is present.

Commands:

```bash
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig exec deploy/appointments-deployment -- id
kubectl --kubeconfig /tmp/appointments-prod-kubeconfig get deploy appointments-deployment \
  -o jsonpath='{.spec.template.spec.containers[0].securityContext}{"\n"}'
```

Expected runtime UID/GID: `10001`.

## Phase 10: CloudFront HTTPS Checkpoint

Only after ALB validation works, ask for approval to deploy the CloudFront companion stack.

This checkpoint:

- Uses CloudFront default `*.cloudfront.net` HTTPS.
- Uses the existing ALB DNS name as origin.
- Keeps CloudFront-to-ALB as HTTP.
- Does not create Route 53, ACM, WAF, or a second ALB.
- May still allow direct ALB app access before hardening.

Validate:

```bash
curl -I http://<cloudfront-domain>/healthz
curl -I https://<cloudfront-domain>/healthz
curl -I https://<cloudfront-domain>/
curl -I --max-time 10 http://<alb-dns-name>/healthz
```

Expected:

- CloudFront HTTP redirects to HTTPS.
- CloudFront HTTPS works.
- Direct ALB may still return the app at this checkpoint.

## Phase 11: ALB Origin Hardening

After CloudFront works, ask for approval to harden the origin path.

Actions:

- Generate or reuse a random origin-header value outside Git.
- Store the value in SSM Parameter Store as a `SecureString`.
- Update CloudFront so it sends the origin header to the ALB.
- Find the regional AWS-managed CloudFront origin-facing prefix list.
- Check security-group rule quota.
- Update the main stack with:
  - `DjangoCsrfTrustedOrigins` including `https://*.cloudfront.net`
  - `CloudFrontOriginHeaderName`
  - `CloudFrontOriginHeaderValue` set to the SSM parameter name, not the raw value
  - `AlbSecurityGroupPrefixLists`
- Rerun or approve `DeployPods`.

Do not print the origin-header value.

Expected after hardening:

- CloudFront HTTPS `/healthz` returns `200`.
- CloudFront HTTPS `/` returns `200`.
- Direct ALB access times out, returns `403`, or returns a safe fallback.
- Direct ALB access does not return the app.
- CodeBuild shows `CLOUDFRONT_ORIGIN_HEADER_VALUE` as `PARAMETER_STORE`, not plaintext.

## Phase 12: Network Security Review

Run `NETWORK-SECURITY-REVIEW.md` after the main stack, Kubernetes deployment, CloudFront companion stack, and origin hardening are complete.

Confirm:

- CloudFront viewer HTTP redirects to HTTPS.
- CloudFront origin protocol is HTTP only for this demo.
- CloudFront has a custom origin header, but the value is not printed.
- ALB listener has header-gated forward plus default deny.
- ALB security group allows listener traffic from the CloudFront origin-facing prefix list after hardening.
- Direct ALB access does not return the app.
- Kubernetes Service remains `ClusterIP`.
- Worker nodes do not have public external IPs.
- RDS is not publicly accessible.
- EKS public API restriction is a separate hardening decision because it can affect `kubectl` and DeployPods.

## Troubleshooting Checklist

- Source fails: confirm repository name, branch, source provider, and CodeStar authorization.
- Unit tests fail: inspect CodeBuild UnitTest logs and fix app/test issues before deploying.
- Image build fails: confirm privileged mode, ECR permissions, Dockerfile path, and build context.
- Deploy fails: confirm DeployPods role has EKS access and `kubectl` download works.
- Pods cannot pull images: confirm ECR repo and image tag rendered correctly.
- Pods crash: confirm Django Secret, database env values, and migrations.
- RDS connection fails: confirm private security groups, IAM DB auth, bootstrap SQL, pod service account, and RDS CA bundle.
- Announcements fail: confirm DynamoDB table name and pod role permissions.
- Ingress has no ALB: confirm AWS Load Balancer Controller, `alb` IngressClass, and Pod Identity association.
- CloudFront returns errors: confirm ALB health and CloudFront origin DNS.
- Direct ALB returns app after hardening: treat as failed hardening; check prefix list, listener rules, and DeployPods rerun.

## Cleanup

Before cleanup, read `CLEANUP.md`.

Use read-only planning first:

```bash
aws cloudformation describe-stacks --profile <student-profile> --region <aws-region>
aws eks list-clusters --profile <student-profile> --region <aws-region>
aws elbv2 describe-load-balancers --profile <student-profile> --region <aws-region>
aws rds describe-db-instances --profile <student-profile> --region <aws-region>
```

Cleanup order:

1. Delete Kubernetes app and Ingress resources.
2. Wait for the Kubernetes-managed ALB to disappear.
3. Delete the CloudFront companion stack if created.
4. Delete the SSM origin-header parameter if created.
5. Empty ECR images and S3 artifact bucket contents if needed.
6. Delete the main CloudFormation stack.
7. Review retained RDS snapshots, logs, source repositories, and artifacts.
8. Confirm no cost-bearing demo resources remain unless intentionally retained.
