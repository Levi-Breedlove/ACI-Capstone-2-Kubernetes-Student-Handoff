# Deployment

## 1. Choose Account Values

Define:

- `AWS_REGION`
- `ACCOUNT_ID`
- `EKS_CLUSTER_NAME`
- `ECR_REPOSITORY`
- `RDS_ENDPOINT`
- `DB_IAM_USER`
- `DB_NAME`
- `DYNAMODB_ANNOUNCEMENTS_TABLE`
- `DJANGO_ALLOWED_HOSTS`
- `DJANGO_CSRF_TRUSTED_ORIGINS`
- `KUBECTL_VERSION`
- Tag values: `Project`, `Phase`, `Environment`, `Owner`, `Repo`, and `ManagedBy`

Do not commit credentials, kubeconfig files, or `.env` files containing secrets.

## 2. Prepare Source Control

Use GitHub with CodeStar Connections or CodeCommit.

For GitHub:

1. Create a private repository.
2. Push the contents of `appointments-app/` as the repository root.
3. Create a CodeStar connection.
4. Configure CodePipeline source to use that connection.

For CodeCommit:

1. Create a repository in your account.
2. Push the contents of `appointments-app/` as the repository root.
3. Configure CodePipeline source to use CodeCommit.

Do not use the whole migration package as the pipeline source root unless you also change the CodeBuild `BuildSpec` paths and Docker build context. The provided CloudFormation assumes `buildspecs/`, `Dockerfile`, `manifests/`, and `manage.py` are at the source root.

For the guided demo path, the intended CodeCommit repository is `appointments-app`, branch `main`, with the contents of `appointments-app/` as the repository root.

## 3. Deploy CloudFormation IaC

Use `iac/cloudformation/appointments-production.yaml` to create the AWS foundation.

```bash
aws cloudformation create-stack \
  --stack-name appointments-prod \
  --template-body file://iac/cloudformation/appointments-production.yaml \
  --parameters file://iac/cloudformation/parameters.example.json \
  --capabilities CAPABILITY_IAM \
  --tags \
    Key=Project,Value=appointments \
    Key=Phase,Value=10 \
    Key=Environment,Value=prod \
    Key=Owner,Value=Student \
    Key=Repo,Value=student-appointments-scheduler \
    Key=ManagedBy,Value=phase10-runbook
```

Replace every placeholder in `parameters.example.json` before deploying. Update the tag parameter values for the account owner and repository if another student is using this package. The stack creates networking, ECR, DynamoDB, RDS, EKS, IAM roles, CodeBuild projects, CodePipeline, and the artifact bucket with project tags where CloudFormation supports tagging.

CloudFormation creates the AWS-side resources and the pipeline. The `PipelineDeployMode` parameter controls whether the pipeline includes a manual `ApproveDeploy` gate before `DeployPods`. Keep `ManualApproval` for first launch until the post-stack Kubernetes steps in `iac/cloudformation/post-deploy.md` are complete, including installing the AWS Load Balancer Controller, bootstrapping the RDS IAM database user, and creating the Django Kubernetes Secret. Use `AutoDeploy` after those prerequisites are proven so each successful image build deploys automatically.

For a fresh launch, keep `PipelineDeployMode=ManualApproval` until the first working deployment is proven. This prevents `DeployPods` from applying manifests before the controller, secret, and private-RDS bootstrap are ready.

When using this package from the student handoff repository, follow the teardown checklist and scripts there before any real cleanup so Kubernetes-managed ALB resources are deleted before the shared AWS foundation.

## 4. Create ECR Manually Only If Not Using CloudFormation

Create an ECR repository, for example:

```bash
aws ecr create-repository --repository-name "$ECR_REPOSITORY" --region "$AWS_REGION"
```

Update the image build CodeBuild project with `ECR_REPOSITORY`.

## 5. Create Or Select Networking

Use at least two Availability Zones. Private subnets are recommended for EKS nodes and RDS. Public subnets are required for internet-facing ALBs.

## 6. Create EKS

The CloudFormation stack creates EKS. The file `scripts/cluster.starter.yaml` remains as a small eksctl reference only.

Install:

- EKS node group.
- OIDC provider.
- EKS Pod Identity or IRSA support.
- AWS Load Balancer Controller.

Authorize only the DeployPods CodeBuild role in EKS using EKS access entries or `aws-auth`. In the CloudFormation package, this is scoped to the `default` namespace.

Generate your local kubeconfig when needed:

```bash
aws eks update-kubeconfig --name "$EKS_CLUSTER_NAME" --region "$AWS_REGION"
```

The included `scripts/config.example` is a sanitized shape only and should not be treated as credentials.

## 7. Configure RDS MySQL

The app image includes `/app/rds-global-bundle.pem` and the Django settings use it for verified TLS when connecting to Amazon RDS through PyMySQL. Do not remove the CA bundle unless you also provide a replacement path through `RDS_CA_BUNDLE`.

The app supports RDS MySQL with IAM database authentication when these environment variables are set:

- `DATABASE_HOST`
- `DATABASE_USER`
- `DATABASE_DB_NAME`

Enable IAM DB authentication on the RDS instance or cluster. Create the MySQL user for IAM authentication and grant only required privileges for the app schema.

The `DeployPods` buildspec runs the packaged Kubernetes migration job before rolling out the web deployment. Bootstrap the RDS database and IAM user first with `iac/cloudformation/db-bootstrap.sql`.

Because the packaged RDS instance is private, the recommended portable path is the Kubernetes Job in `iac/cloudformation/db-bootstrap-job.yml`. Create a temporary Kubernetes Secret for the RDS master username/password and a temporary ConfigMap for the rendered SQL file, run the job from inside EKS, verify it completed, then delete the job, secret, and ConfigMap.

## 8. Configure DynamoDB

Create the announcements table. The lab name was `DEV_Announcement`; production should use an environment-specific name such as `prod-appointments-announcements`.

Set `ANNOUNCEMENTS_TABLE` in the Kubernetes deployment.

## 9. Create Kubernetes Secret

Create the Django secret key as a Kubernetes Secret:

```bash
kubectl create secret generic appointments-django --from-literal=secret-key='<generate-a-long-random-value>'
```

## 10. Prepare Clean ALB Rerouting

The production manifests keep two web replicas and add rollout/drain settings for cleaner rerouting when a pod or worker node is removed:

- Topology spread across worker node hostnames, with `minDomains: 2` and `matchLabelKeys: pod-template-hash` so each new ReplicaSet keeps one web pod on each node during rollout.
- `maxUnavailable: 0` rolling updates.
- `appointments-pdb.yml` with `minAvailable: 1`.
- A 30-second `preStop` drain window and 60-second termination grace period.
- Faster `/healthz` readiness checks and matching ALB health check annotations.
- `deregistration_delay.timeout_seconds=30` on the ALB target group.

For the strongest ALB-aware rollout behavior, enable AWS Load Balancer Controller pod readiness gate injection before app pods are recreated:

```bash
kubectl label namespace default elbv2.k8s.aws/pod-readiness-gate-inject=enabled --overwrite
```

This namespace label is a one-time admin setup action. The packaged DeployPods role remains scoped to the `default` namespace and does not mutate namespace objects.

## 11. Optional HTTPS Demo

For the affordable HTTPS demo path, keep the same AWS Load Balancer Controller-managed ALB and one target group. Do not add a second ALB, WAF, Shield Advanced, mTLS, or extra standby routing unless the demo goal changes.

### No-Custom-Domain CloudFront Path

Use this path when you want the browser to show HTTPS without buying or configuring a domain.

1. Keep `AlbCertificateArn` blank so the Kubernetes-managed ALB stays HTTP-only.
2. Wait until the app Ingress has an ALB DNS name.
3. Generate a random origin header value outside the repo, for example with `openssl rand -hex 32`.
4. Store that value in SSM Parameter Store as a `SecureString`, for example `/appointments/prod/cloudfront-origin-header-value`.
5. Look up the regional AWS-managed CloudFront origin-facing prefix list ID.
6. Deploy `iac/cloudformation/cloudfront-default-https.yaml` as a companion stack with `OriginDnsName=<ALB_DNS>`, `OriginAccessHeaderName`, `OriginAccessHeaderValue`, and `PriceClass=PriceClass_100`. Keep the parameter file local and untracked.
7. Read the companion stack `CloudFrontDefaultHttpsUrl` output.
8. Update the main app stack parameters:
   - `DjangoCsrfTrustedOrigins=https://*.amazonaws.com,https://*.cloudfront.net`
   - `CloudFrontOriginHeaderName=<same-header-name>`
   - `CloudFrontOriginHeaderValue=<ssm-securestring-name>`
   - `AlbSecurityGroupPrefixLists=<cloudfront-origin-facing-prefix-list-id>`
9. Re-run the pipeline or `DeployPods` after the main stack parameter update so the pods receive the CloudFront CSRF origin, secure-cookie settings, ALB header gate, and CloudFront prefix-list restriction.

CloudFront uses its default `*.cloudfront.net` certificate for the viewer HTTPS link and forwards origin traffic to the existing ALB over HTTP. The ALB forwards to pods over HTTP. That is expected for this demo and is not end-to-end TLS. Do not set `DjangoSecureHstsSeconds` above `0` for this temporary default-domain path.

Direct ALB access should not return the application after this hardening is applied. A normal laptop request should fail at the ALB security group because only the CloudFront origin-facing prefix list can reach the listener. If a request reaches the listener without the CloudFront origin header, the expected response is the fixed `403` default action. If the AWS Load Balancer Controller cannot render that fixed response in a specific version, a `404` fallback is acceptable only if the app is not reached. A public direct-ALB app response is not acceptable for the hardened demo.

### Custom-Domain ALB HTTPS Path

Use this path later if a polished demo hostname is required.

Before enabling ALB-native HTTPS:

- Create or reuse a public ACM certificate in the same Region as the ALB.
- Validate the certificate with DNS.
- Use a demo hostname such as `appointments.example.com`.
- Point the hostname to the ALB DNS name after the Ingress is provisioned.
- Set `DjangoAllowedHosts` to the concrete hostname.
- Set `DjangoCsrfTrustedOrigins` to the concrete `https://` origin.

Relevant CloudFormation parameters:

- `AlbCertificateArn`: blank means HTTP-only; a certificate ARN enables HTTPS rendering.
- `AlbInboundCidrs`: defaults to `0.0.0.0/0`; used only when CloudFront prefix-list hardening is not enabled.
- `AlbSecurityGroupPrefixLists`: set to the regional `com.amazonaws.global.cloudfront.origin-facing` prefix list ID for the no-custom-domain CloudFront path.
- `CloudFrontOriginHeaderName`: custom origin header name shared by CloudFront and the ALB rule.
- `CloudFrontOriginHeaderValue`: for the main app stack, set this to the SSM Parameter Store `SecureString` name that contains the generated header value. Do not set it to the raw header value, because CodeBuild project environment variables can be displayed as plaintext.
- `AlbSslPolicy`: defaults to a modern TLS 1.2/1.3 ALB policy.
- `AlbHttpsRedirect`: defaults to `true`, which redirects HTTP listener traffic to HTTPS.
- `OriginDnsName`: companion CloudFront stack parameter set to the existing ALB DNS name.
- `PriceClass`: companion CloudFront stack parameter; keep `PriceClass_100` to control demo cost.
- `DjangoSecureHstsSeconds`: defaults to `0`; increase only after the custom HTTPS domain is stable.

`DeployPods` renders the Ingress annotations for ALB-native HTTPS when `AlbCertificateArn` is supplied. It also enables secure Django cookies when either `AlbCertificateArn` is supplied or `DjangoCsrfTrustedOrigins` includes `cloudfront.net`.

## 12. Manifest Placeholders

The `DeployPods` CodeBuild project replaces these placeholders in the web deployment and migration job manifests during deployment:

- `ACCOUNT_ID`
- `AWS_REGION`
- `ECR_REPOSITORY`
- `RDS_ENDPOINT`
- `DB_IAM_USER`
- `DB_NAME`
- `DYNAMODB_ANNOUNCEMENTS_TABLE`
- `ALLOWED_HOSTS`
- `CSRF_TRUSTED_ORIGINS`
- HTTPS and Django secure-cookie values derived from `AlbCertificateArn`, `AlbHttpsRedirect`, `DjangoCsrfTrustedOrigins`, and `DjangoSecureHstsSeconds`
- `TAG_PROJECT`
- `TAG_PHASE`
- `TAG_ENVIRONMENT`
- `TAG_OWNER`
- `TAG_REPO`
- `TAG_MANAGED_BY`

The CloudFormation stack passes the values into the deploy project from parameters and stack outputs. The manifest set includes `appointments-serviceaccount.yml`, and the CloudFormation stack creates an EKS Pod Identity association for `appointments-sa`. The ingress manifest uses these tag placeholders so the AWS Load Balancer Controller can tag the Application Load Balancer resources it creates.

For first ALB discovery, `DjangoAllowedHosts=*` may be used temporarily. After the ALB DNS name or custom domain is known, update the host and CSRF values to the concrete hostname/origin. If the first ingress is HTTP-only, use the matching `http://` origin until TLS is configured.

## 13. Configure CodeBuild

Create at least two projects:

- Image build project using `buildspecs/buildspec_buildimage.yml`.
- Deploy project using `buildspecs/buildspec_deploypods.yml`.

Set environment variables:

- `AWS_DEFAULT_REGION`
- `ECR_REPOSITORY` with your repository name, replacing `replace-me-ecr-repository`
- `EKS_CLUSTER_NAME` with your cluster name, replacing `replace-me-eks-cluster`
- Database, DynamoDB, host, CSRF, and `KUBECTL_VERSION` values if you are not using the provided CloudFormation stack.
- Optional ALB HTTPS values if you are not using the provided CloudFormation stack.
- Tag values if you are not using the provided CloudFormation stack.

Enable privileged mode for the Docker image build project.

## 14. Configure CodePipeline

Recommended stages:

1. Source from GitHub or CodeCommit.
2. Unit tests with `buildspec_unittest.yml`.
3. Build and push image with `buildspec_buildimage.yml`.
4. Optional manual `ApproveDeploy` gate when `PipelineDeployMode=ManualApproval`.
5. Deploy pods with `buildspec_deploypods.yml`; in `AutoDeploy` mode this runs immediately after `BuildImage`.

Use an encrypted S3 artifact bucket and a scoped pipeline service role.

## 15. Verify

```bash
kubectl get pods
kubectl get service appointments-service
kubectl get ingress appointments-ingress -o wide
kubectl get pdb appointments-pdb
kubectl get pods -l app=appointments-deployment -o wide
```

After CloudFront origin hardening, do not use `kubectl describe ingress` or dump full Ingress annotations. The hardened ALB condition annotation can include the CloudFront origin-header value.

Open the ALB DNS name, CloudFront default HTTPS URL, or HTTPS demo hostname. Confirm `/healthz` returns a healthy response, confirm HTTP redirects to HTTPS when enabled, then confirm services, hairdressers, dates, time booking, RDS persistence, and DynamoDB announcements.

## 16. Rollback

Preferred rollback options:

- Revert the source commit with `git revert <commit-id>` and let the pipeline redeploy.
- Redeploy a previous ECR image tag by updating the manifest image tag and committing the change.
- Use `kubectl rollout undo deployment/appointments-deployment` only as an emergency operational rollback, then reconcile source control.
