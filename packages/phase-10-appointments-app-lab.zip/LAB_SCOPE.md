# Lab Scope

This package intentionally keeps the Phase/Lab 10 assumptions in place.

Preserved lab-only assumptions:

- EKS cluster name: `eks-cluster`.
- CodePipeline pipeline: `ApplicationPipeline`.
- CodeBuild deployment action/project: `DeployPods`.
- CodeBuild service role reference: `CodeBuildProjectRole`.
- Source control flow: AWS CodeCommit to CodePipeline.
- ECR repository: `containers-image-repository`.
- Kubernetes deployment/service/ingress manifest layout under `appointments-app/manifests/`.
- Lab region and lab resource names embedded in the lab manifests and cluster reference.
- RDS MySQL access through IAM database authentication.
- DynamoDB announcements table name: `DEV_Announcement`.

Out of scope for this lab package:

- Creating a portable production AWS account baseline.
- Replacing lab networking, IAM, or database resources.
- Adding a full Infrastructure as Code stack.
- Including local kubeconfig/auth state.

The package includes `scripts/config.example` as a sanitized reference only. It is not a usable kubeconfig until populated by AWS CLI or replaced with a locally generated file outside the package.

The staged lab copy changes only the Django secret-key handling to avoid packaging a secret-like hardcoded value. It keeps an insecure placeholder fallback for lab compatibility and supports `DJANGO_SECRET_KEY` when supplied by the environment.
