# Phase 10 Appointments Scheduler Lab Package

This package is the lab-safe completed version of the Phase/Lab 10 hair salon appointments scheduler app.

It contains:

- `appointments-app/`: Django appointments scheduler application.
- `appointments-app/Dockerfile`: container build definition for the Django app.
- `appointments-app/buildspecs/buildspec_unittest.yml`: CodeBuild unit test buildspec.
- `appointments-app/buildspecs/buildspec_buildimage.yml`: CodeBuild buildspec that builds the Docker image and pushes it to ECR.
- `appointments-app/buildspecs/buildspec_deploypods.yml`: CodeBuild buildspec for the Lab 10 `DeployPods` action that updates kubeconfig and deploys Kubernetes manifests to Amazon EKS.
- `appointments-app/manifests/`: Kubernetes deployment, service, and ingress manifests.
- `scripts/cluster.yaml`: lab EKS cluster configuration reference.
- `scripts/config.example`: sanitized kubeconfig shape for the lab cluster.

## Lab 10 Mapping

This package preserves the Lab 10 flow:

1. Source code is stored in the lab CodeCommit repository.
2. `ApplicationPipeline` runs source, test, image build, and deployment stages.
3. The image build stage pushes `containers-image-repository` tags to Amazon ECR.
4. The `DeployPods` CodeBuild project uses `buildspec_deploypods.yml`.
5. `DeployPods` runs `aws eks update-kubeconfig --name eks-cluster`.
6. Kubernetes manifests are applied to `eks-cluster`.
7. The app is exposed through the AWS load balancer resources created from the service and ingress manifests.

## Lab Account Requirements

The AWS lab account must already provide:

- CodeCommit source repository connected to `ApplicationPipeline`.
- CodePipeline pipeline named `ApplicationPipeline`.
- CodeBuild projects for unit test, image build, and `DeployPods`.
- CodeBuild service role named or mapped as `CodeBuildProjectRole`.
- ECR repository named `containers-image-repository`.
- EKS cluster named `eks-cluster`.
- Node IAM role and cluster IAM role expected by the lab cluster configuration.
- Kubernetes access for the CodeBuild service role.
- RDS MySQL endpoint and database user referenced by the lab Kubernetes deployment.
- DynamoDB table named `DEV_Announcement`.
- AWS Load Balancer Controller or equivalent lab setup for ALB ingress.

## Verify The App

After the pipeline finishes:

1. Open the DNS name printed by the `DeployPods` post-build command or inspect the Kubernetes ingress/load balancer.
2. Confirm the appointments page loads.
3. Select a service, hairdresser, date, and time.
4. Submit an appointment.
5. Confirm the selected appointment time becomes unavailable.
6. Confirm announcements load from the `DEV_Announcement` DynamoDB table.

Useful lab commands:

```bash
aws eks update-kubeconfig --name eks-cluster
kubectl get pods
kubectl get service appointments-service
kubectl get ingress appointments-ingress
```

## Rollback With Git Revert

Lab 10 demonstrates rollback through source control.

From the CodeCommit working copy:

```bash
git log --oneline
git revert <commit-id>
git push
```

Pushing the revert commit causes `ApplicationPipeline` to run again. The image build stage creates a new image from the reverted source, and `DeployPods` redeploys the app to EKS.

## Packaging Notes

The original top-level `scripts` folder was not moved. The local kubeconfig file `scripts/config` is intentionally excluded from this zip because package artifacts must not include local auth files or cluster credentials. Use `aws eks update-kubeconfig --name eks-cluster` in the lab account to regenerate the real local kubeconfig when needed.
